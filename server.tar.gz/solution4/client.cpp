#include "socketlib.hpp"

int main()
{
	int client;
	const char *c = "socket.txt";
	char *buf = new char[100];
	std::string input;
	
	client = ConnectToServer(c);
	if (client > 0)
	{
		ReceiveFromServer(client, buf, 100);
		cout << buf << endl;
		std::cout << "Enter an SQL command\n";
		std::getline(std::cin, input);
		send (client, input.c_str(), input.size(), 0);
		close(client);
	}
	delete []buf;
}