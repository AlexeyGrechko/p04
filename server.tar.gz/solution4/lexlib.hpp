#include <iostream>
#include <vector>
#include <stack>
#include <exception>
#include <algorithm>
#include "tablelib.hpp"

using std::string;
using std::cout;
using std::endl;
using std::cerr;

bool output;
string error_message = "Error: unknown";



// ___LEXER NAMESPACE___
namespace lexer
{
	int c;
	enum token_t {SELECT, INSERT, UPDATE, DELETE, CREATE, DROP,
				  FROM, WHERE, INTO, TABLE, TEXT, LONG, NOT, AND,
				  OR, LIKE, IN, ALL, SET, PLUS, MINUS, MULT, DIV, 
				  PERCENT, EQUAL, NOT_EQUAL, GREATER, LESSER, 
				  SOFT_GREATER, SOFT_LESSER, NUMBER, IDENT, END,
				  COMMA, OPEN, CLOSE, OPEN_SQUARE, CLOSE_SQUARE,
				  UNDERSCORE, CIRCUMFLEX, STRING, ERROR, EXIT};
	enum token_t token;
	int current_line {0};
    int current_position {0};
    int current_end_position {0};
    std::string current_text;
	
	void PrintToken(enum token_t token)
	{
		switch (token)
		{
			case 0:
				cout << "SELECT ";          
			break;
			case 1:
				cout << "INSERT ";      
			break;
			case 2:
				cout << "UPDATE ";            
			break;
			case 3:
				cout << "DELETE ";        
			break;
			case 4:
				cout << "CREATE ";       
			break;
			case 5:
				cout << "DROP ";          
			break;
			case 6:
				cout << "FROM ";         
			break;
			case 7:
				cout << "WHERE ";             
			break;
			case 8:
				cout << "INTO ";               
			break;
			case 9:
				cout << "TABLE ";           
			break;
			case 10:
				cout << "TEXT ";            
			break;
			case 11:
				cout << "LONG ";            
			break;
			case 12:
				cout << "NOT ";             
			break;
			case 13:
				cout << "AND ";             
			break;
			case 14:
				cout << "OR ";              
			break;
			case 15:
				cout << "LIKE ";           
			break;
			case 16:
				cout << "IN ";            
			break;
			case 17:
				cout << "ALL ";             
			break;
			case 18:
				cout << "SET ";             
			break;
			
			
			case 19:
				cout << "PLUS ";            
			break;
			case 20:
				cout << "MINUS ";           
			break;
			case 21:
				cout << "MULT ";            
			break;
			case 22:
				cout << "DIV ";             
			break;
			case 23:
				cout << "PERCENT ";         
			break;
			case 24:
				cout << "EQUAL ";          
			break;
			case 25:
				cout << "NOT_EQUAL ";
			break;
			case 26:
				cout << "GREATER ";
			break;
			case 27:
				cout << "LESSER ";
			break;
			case 28:
				cout << "SOFT_GREATER ";
			break;
			case 29:
				cout << "SOFT_LESSER ";
			break;
			case 30:
				cout << "NUMBER ";          
			break;
			case 31:
				cout << "IDENT ";           
			break;
			case 32:
				cout << "END ";           
			break;
			case 33:
				cout << "COMMA ";
			break;
			case 34:
				cout << "OPEN ";
			break;
			case 35:
				cout << "CLOSE ";
			break;
			case 36:
				cout << "OPEN_SQUARE ";
			break;
			case 37:
				cout << "CLOSE_SQUARE ";
			break;
			case 38:
				cout << "UNDERSCORE ";
			break;
			case 39:
				cout << "CIRCUMFLEX ";
			break;
			case 40:
				cout << "STRING ";
			break;
			case 41:
				cout << "ERROR ";
			break;
			case 42:
				cout << "EXIT ";
			break;
		}
	}
	
	void init()
	{
		c = getchar();
	}
	
	void next()
	{
		current_text.clear();
		current_position = current_end_position;
		enum state_t {START_S, IDENT_S, NUMBER_S, STRING_S, STRING_END_S, OK_S, A_S, AN_S, AND_S, AL_S, ALL_S, C_S, CR_S, CRE_S, CREA_S, CREAT_S, 
					  CREATE_S, D_S, DE_S, DEL_S, DELE_S, DELET_S, DELETE_S, DR_S, DRO_S, DROP_S, F_S, FR_S, FRO_S, FROM_S, 
					  I_S, IN_S, INS_S, INSE_S, INSER_S, INSERT_S, INT_S, INTO_S, L_S, LI_S, LIK_S, LIKE_S, LO_S, LON_S, 
					  LONG_S, N_S, NO_S, NOT_S, O_S, OR_S, S_S, SE_S, SET_S, SEL_S, SELE_S, SELEC_S, SELECT_S, T_S, 
					  TE_S, TEX_S, TEXT_S, TA_S, TAB_S, TABL_S, TABLE_S, U_S, UP_S, UPD_S, UPDA_S, UPDAT_S, UPDATE_S,
					  W_S, WH_S, WHE_S, WHER_S, WHERE_S, PLUS_S, MINUS_S, MULT_S, DIV_S, PERCENT_S, COMMA_S, OPEN_S, CLOSE_S,
					  OPEN_SQUARE_S, CLOSE_SQUARE_S, UNDERSCORE_S, CIRCUMFLEX_S, EQUAL_S, EXCLAMATION_S, NOT_EQUAL_S, 
					  GREATER_S, LESSER_S, SOFT_GREATER_S, SOFT_LESSER_S, ERROR_S, E_S, EX_S, EXI_S, EXIT_S};
		
		enum state_t state = START_S;
		
		while (state != OK_S)
		{
			switch(state)
			{
				//Starting symbol
				case START_S:
					if (std::isspace(c))
					{
						// stay in S
					} 
					else if (c == 'A') 
					{
						state = A_S;
					} 
					else if (c == 'C') 
					{
						state = C_S;
					} 
					else if (c == 'D') 
					{
						state = D_S;
					} 
					else if (c == 'E') 
					{
						state = E_S;
					}
					else if (c == 'F') 
					{
						state = F_S;
					} 
					else if (c == 'I') 
					{
						state = I_S;
					} 
					else if (c == 'L') 
					{
						state = L_S;
					} 
					else if (c == 'N') 
					{
						state = N_S;
					} 
					else if (c == 'O') 
					{
						state = O_S;
					} 
					else if (c == 'S') 
					{
						state = S_S;
					} 
					else if (c == 'T') 
					{
						state = T_S;
					} 
					else if (c == 'U') 
					{
						state = U_S;
					} 
					else if (c == 'W') 
					{
						state = W_S;
					} 
					
					else if (c == '+') 
					{
						state = PLUS_S;
					} 
					else if (c == '-') 
					{
						state = MINUS_S;
					} 
					else if (c == '*') 
					{
						state = MULT_S;
					} 
					else if (c == '/') 
					{
						state = DIV_S;
					} 
					else if (c == '%') 
					{
						state = PERCENT_S;
					} 
					else if (c == ',') 
					{
						state = COMMA_S;
					} 
					else if (c == '(') 
					{
						state = OPEN_S;
					} 
					else if (c == ')') 
					{
						state = CLOSE_S;
					} 
					else if (c == '[') 
					{
						state = OPEN_SQUARE_S;
					} 
					else if (c == ']') 
					{
						state = CLOSE_SQUARE_S;
					} 
					else if (c == '_') 
					{
						state = UNDERSCORE_S;
					} 
					else if (c == '^') 
					{
						state = CIRCUMFLEX_S;
					} 
					
					else if (c == '=') 
					{
						state = EQUAL_S;
					} 
					else if (c == '!') 
					{
						state = EXCLAMATION_S;
					} 
					else if (c == '>') 
					{
						state = GREATER_S;
					} 
					else if (c == '<') 
					{
						state = LESSER_S;
					} 
					
					else if (std::isalpha(c))
					{
						state = IDENT_S;
					}
					else if (std::isdigit(c))
					{
						state = NUMBER_S;
					}
					else if (c == EOF) 
					{
						token = END;
						state = OK_S;
					} 
					
					else if (c == '\'')
					{
						state = STRING_S;
					}
					
					else 
					{
						output = false;
						token = ERROR;
						state = ERROR_S;
					}
				break;
			
				//Words starting with A
				case A_S:
					if (c == 'N') 
						state = AN_S;
					else if (c == 'L') 
						state = AL_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				
				case AN_S:
					if (c == 'D') 
						state = AND_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case AND_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = AND;
						state = OK_S;
					}
				break;
				
				case AL_S:
					if (c == 'L') 
						state = ALL_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				
				case ALL_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = ALL;
						state = OK_S;
					}
				break;
				
				//Words starting with C
				case C_S:
					if (c == 'R') 
						state = CR_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case CR_S:
					if (c == 'E') 
						state = CRE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case CRE_S:
					if (c == 'A') 
						state = CREA_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case CREA_S:
					if (c == 'T') 
						state = CREAT_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case CREAT_S:
					if (c == 'E') 
						state = CREATE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case CREATE_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = CREATE;
						state = OK_S;
					}
				break;
				
				//Words starting with D
				case D_S:
					if (c == 'E') 
						state = DE_S;
					else if (c == 'R')
						state = DR_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case DE_S:
					if (c == 'L') 
						state = DEL_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case DEL_S:
					if (c == 'E') 
						state = DELE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case DELE_S:
					if (c == 'T') 
						state = DELET_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case DELET_S:
					if (c == 'E') 
						state = DELETE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case DELETE_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = DELETE;
						state = OK_S;
					}
				break;
				case DR_S:
					if (c == 'O') 
						state = DRO_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case DRO_S:
					if (c == 'P') 
						state = DROP_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case DROP_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = DROP;
						state = OK_S;
					}
				break;
				
				//Words starting with E
				case E_S:
					if (c == 'X') 
						state = EX_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case EX_S:
					if (c == 'I') 
						state = EXI_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case EXI_S:
					if (c == 'T') 
						state = EXIT_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case EXIT_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = EXIT;
						state = OK_S;
					}
				break;
				
				//Words starting with F 
				case F_S:
					if (c == 'R') 
						state = FR_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case FR_S:
					if (c == 'O') 
						state = FRO_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case FRO_S:
					if (c == 'M') 
						state = FROM_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case FROM_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = FROM;
						state = OK_S;
					}
				break;
				
				//Words starting with I
				case I_S:
					if (c == 'N') 
						state = IN_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case IN_S:
					if (c == 'S') 
						state = INS_S;
					else if (c == 'T') 
						state = INT_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IN;
					}
				break;
				case INS_S:
					if (c == 'E') 
						state = INSE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case INSE_S:
					if (c == 'R') 
						state = INSER_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case INSER_S:
					if (c == 'T') 
						state = INSERT_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case INSERT_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = INSERT;
						state = OK_S;
					}
				break;
				case INT_S:
					if (c == 'O') 
						state = INTO_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case INTO_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = INTO;
						state = OK_S;
					}
				break;
				
				//Words starting with L
				case L_S:
					if (c == 'I') 
						state = LI_S;
					else if (c == 'O') 
						state = LO_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case LI_S:
					if (c == 'K') 
						state = LIK_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case LIK_S:
					if (c == 'E') 
						state = LIKE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case LIKE_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = LIKE;
						state = OK_S;
					}
				break;
				case LO_S:
					if (c == 'N') 
						state = LON_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case LON_S:
					if (c == 'G') 
						state = LONG_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case LONG_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = LONG;
						state = OK_S;
					}
				break;
				
				//Words starting with N
				case N_S:
					if (c == 'O') 
						state = NO_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case NO_S:
					if (c == 'T') 
						state = NOT_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case NOT_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = NOT;
						state = OK_S;
					}
				break;
				
				//Words starting with O
				case O_S:
					if (c == 'R') 
						state = OR_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case OR_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = OR;
						state = OK_S;
					}
				break;
				
				//Words starting with S
				case S_S:
					if (c == 'E') 
						state = SE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case SE_S:
					if (c == 'T') 
						state = SET_S;
					else if (c == 'L') 
						state = SEL_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case SET_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = SET;
						state = OK_S;
					}
				break;
				case SEL_S:
					if (c == 'E') 
						state = SELE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case SELE_S:
					if (c == 'C') 
						state = SELEC_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case SELEC_S:
					if (c == 'T') 
						state = SELECT_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case SELECT_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = SELECT;
						state = OK_S;
					}
				break;
				
				//Words starting with T
				case T_S:
					if (c == 'E') 
						state = TE_S;
					else if (c == 'A') 
						state = TA_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case TE_S:
					if (c == 'X') 
						state = TEX_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case TEX_S:
					if (c == 'T') 
						state = TEXT_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case TEXT_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = TEXT;
						state = OK_S;
					}
				break;
				case TA_S:
					if (c == 'B') 
						state = TAB_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case TAB_S:
					if (c == 'L') 
						state = TABL_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case TABL_S:
					if (c == 'E') 
						state = TABLE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case TABLE_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = TABLE;
						state = OK_S;
					}
				break;
				
				//Words starting with U
				case U_S:
					if (c == 'P') 
						state = UP_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case UP_S:
					if (c == 'D') 
						state = UPD_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case UPD_S:
					if (c == 'A') 
						state = UPDA_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case UPDA_S:
					if (c == 'T') 
						state = UPDAT_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case UPDAT_S:
					if (c == 'E') 
						state = UPDATE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case UPDATE_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = UPDATE;
						state = OK_S;
					}
				break;
				
				//Words starting with W
				case W_S:
					if (c == 'H') 
						state = WH_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case WH_S:
					if (c == 'E') 
						state = WHE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case WHE_S:
					if (c == 'R') 
						state = WHER_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case WHER_S:
					if (c == 'E') 
						state = WHERE_S;
					else if ((std::isdigit(c))||(std::isalpha(c)))
						state = IDENT_S;
					else 
					{
						state = OK_S;
						token = IDENT;
					}
				break;
				case WHERE_S:
					if ((std::isdigit(c))||(std::isalpha(c)))
					{
						state = IDENT_S;
					}
					else 
					{
						token = WHERE;
						state = OK_S;
					}
				break;
				
				//One symbol tokens
				case PLUS_S:
					token = PLUS;
					state = OK_S;
				break;
				case MINUS_S:
					token = MINUS;
					state = OK_S;
				break;
				case MULT_S:
					token = MULT;
					state = OK_S;
				break;
				case DIV_S:
					token = DIV;
					state = OK_S;
				break;
				case PERCENT_S:
					token = PERCENT;
					state = OK_S;
				break;
				case COMMA_S:
					token = COMMA;
					state = OK_S;
				break;
				case OPEN_S:
					token = OPEN;
					state = OK_S;
				break;
				case CLOSE_S:
					token = CLOSE;
					state = OK_S;
				break;
				case OPEN_SQUARE_S:
					token = OPEN_SQUARE;
					state = OK_S;
				break;
				case CLOSE_SQUARE_S:
					token = CLOSE_SQUARE;
					state = OK_S;
				break;
				case UNDERSCORE_S:
					token = UNDERSCORE;
					state = OK_S;
				break;
				case CIRCUMFLEX_S:
					token = CIRCUMFLEX;
					state = OK_S;
				break;
				
				//Comparison ops
				case EQUAL_S:
					token = EQUAL;
					state = OK_S;
				break;
				case EXCLAMATION_S:
					if (c == '=') 
					{
						state = NOT_EQUAL_S;
					}
					else 
					{
						output = false;
						state = OK_S;
						token = ERROR;
					}
				break;
				case NOT_EQUAL_S:
					token = NOT_EQUAL;
					state = OK_S;
				break;
				case GREATER_S:
					if (c == '=') 
					{
						state = SOFT_GREATER_S;
					}
					else 
					{
						token = GREATER;
						state = OK_S;
					}
				break;
				case SOFT_GREATER_S:
					token = SOFT_GREATER;
					state = OK_S;
				break;
				case LESSER_S:
					if (c == '=') 
					{
						state = SOFT_LESSER_S;
					}
					else 
					{
						token = LESSER;
						state = OK_S;
					}
				break;
				case SOFT_LESSER_S:
					token = SOFT_LESSER;
					state = OK_S;
				break;
				
				
				case IDENT_S:
					if ((std::isdigit(c))||(std::isalpha(c))||(c == '_'))
					{
						//stay in IDENT
					}
					else 
					{
						token = IDENT;
						state = OK_S;
					}
						
				break;
				
				case NUMBER_S:
					if (std::isdigit(c))
					{
						//stay in NUMBER
					}
					else if (std::isalpha(c))
					{
						output = false;
						token = ERROR;
						state = OK_S;
					}
					else 
					{
						token = NUMBER;
						state = OK_S;
					}
						
				break;
				
				case STRING_S:
					if (c == EOF)
					{
						output = false;
						token = ERROR;
						state = OK_S;
					}
					else if (c != '\'')
					{
						//stay in STRING
					}
					else 
					{
						state = STRING_END_S;
					}
						
				break;
				
				case STRING_END_S:
					token = STRING;
					state = OK_S;
				break;
				
				case ERROR_S:
					token = ERROR;
					state = OK_S;
				break;
	
				case OK_S:
			
				break;
			}
			if (state != OK_S)
			{
				if (c == '\n')
				{
					current_line++;
					current_position = current_end_position = 0;
				}
				else if (std::isspace(c)) 
				{
                    ++ current_position;
                    ++ current_end_position;
                } 
				else 
				{
                    ++ current_end_position;
                }

                if (!std::isspace(c) && token != END) 
				{
                    current_text.push_back(c);
                }
				
				c = getchar();
			}
		}
	}
}

/*
	---GRAMMAR---
	
START -> select SELECT_SENTENCE | insert INSERT_SENTENCE | update UPDATE_SENTENCE |
	 delete DELETE_SENTENCE | create CREATE_SENTENCE | drop DROP_SENTENCE | EXIT_SENTENCE
	 
SELECT_SENTENCE -> FIELD_LIST from TABLE_NAME WHERE_CLAUSE
INSERT_SENTENCE -> into TABLE_NAME (FIELD_VALUE {, FIELD_VALUE})
UPDATE_SENTENCE -> TABLE_NAME set FIELD_NAME = EXPRESSION WHERE_CLAUSE
DELETE_SENTENCE -> from TABLE_NAME WHERE_CLAUSE
CREATE_SENTENCE -> table TABLE_NAME (FIELD_DESCRIPTION_LIST)
DROP_SENTENCE -> table TABLE_NAME

TABLE_NAME -> ident
FIELD_NAME -> ident
FIELD_LIST -> ident {, ident} | *
FIELD_VALUE -> string | number
FIELD_DESCRIPTION_LIST -> FIELD_DESCRIPTION {, FIELD_DESCRIPTION}
FIELD_DESCRIPTION -> FIELD_NAME FIELD_TYPE
FIELD_TYPE -> text (number) | long

WHERE_CLAUSE -> where TEXT_FIELD_NAME @not@ like STRING_SAMPLE |
				where EXPRESSION @not@ in (VALUE_LIST) |
				where (BOOL_EXPRESSION) |
				where all
STRING_SAMPLE -> string 
TEXT_FIELD_NAME	-> ident	
VALUE_LIST -> string {, string} | number {, number}
EXPRESSION -> LONG_EXPRESSION | TEXT_EXPRESSION

LONG_EXPRESSION -> LONG_ADD {SIGN_ADD LONG_ADD}
SIGN_ADD -> + | -
LONG_ADD -> LONG_MULT {SIGN_MULT LONG_MULT}
SIGN_MULT -> * | / | %
LONG_MULT -> LONG_VALUE | (LONG_EXPRESSION)
LONG_VALUE -> LONG_FIELD_NAME | number
LONG_FIELD_NAME -> ident

TEXT_EXPRESSION -> TEXT_FIELD_NAME | string

BOOL_EXPRESSION -> BOOL_ADD {or BOOL_ADD}
BOOL_ADD -> BOOL_MULT {and BOOL_MULT}
BOOL_MULT -> not BOOL_MULT | (BOOL_EXPRESSION) | (COMPARISON)
COMPARISON -> TEXT_COMPARISON | LONG_COMPARISON
TEXT_COMPARISON -> TEXT_EXPRESSION SIGN_COMP TEXT_EXPRESSION
LONG_COMPARISON -> LONG_EXPRESSION SIGN_COMP LONG_EXPRESSION
SIGN_COMP -> = | != | < | > | <= | >=

*/

std::vector <lexer::token_t> look_ahead;
std::vector <std::string> look_ahead_text;

namespace parser
{
	
	int START();
	int SELECT_SENTENCE();
	int INSERT_SENTENCE();
	int UPDATE_SENTENCE();
	int DELETE_SENTENCE();
	int CREATE_SENTENCE();
	int DROP_SENTENCE();
	int EXIT_SENTENCE();
	int TABLE_NAME();
	int FIELD_NAME();
	int FIELD_LIST();
	int FIELD_VALUE();
	int FIELD_DESCRIPTION_LIST();
	int FIELD_DESCRIPTION();
	int FIELD_TYPE();
	int EXPRESSION();
	int LONG_EXPRESSION();
	int TEXT_EXPRESSION();
	int SIGN_ADD();
	int LONG_ADD();
	int SIGN_MULT();
	int LONG_MULT();
	int LONG_VALUE();
	int LONG_FIELD_NAME();
	
	int WHERE_CLAUSE();
	int STRING_SAMPLE();
	int TEXT_FIELD_NAME();
	int VALUE_LIST();
	
	int WHERE_EXPRESSION();
	int WHERE_LONG_EXPRESSION();
	int WHERE_TEXT_EXPRESSION();
	int WHERE_SIGN_ADD();
	int WHERE_LONG_ADD();
	int WHERE_SIGN_MULT();
	int WHERE_LONG_MULT();
	int WHERE_LONG_VALUE();
	int WHERE_LONG_FIELD_NAME();
	
	int BOOL_EXPRESSION();
	int BOOL_ADD();
	int BOOL_MULT();
	int COMPARISON();
	int TEXT_COMPARISON();
	int LONG_COMPARISON();
	int SIGN_COMP();
	
	int i = 0;
	
	int START()
	{
		if (lexer::token == lexer::SELECT) 
		{
			lexer::next();
			SELECT_SENTENCE();
		}
		else if (lexer::token == lexer::INSERT) 
		{
			lexer::next();
			INSERT_SENTENCE();
		}
		else if (lexer::token == lexer::UPDATE)
		{
			lexer::next();
			UPDATE_SENTENCE();
		}
		else if (lexer::token == lexer::DELETE)
		{
			lexer::next();
			DELETE_SENTENCE();
		}
		else if (lexer::token == lexer::CREATE)
		{
			lexer::next();
			CREATE_SENTENCE();
		}
		else if (lexer::token == lexer::DROP)
		{
			lexer::next();
			DROP_SENTENCE();
		}
		else if (lexer::token == lexer::EXIT)
		{
			lexer::next();
			EXIT_SENTENCE();
		}
		else
		{
			if (output)
				error_message = "Error: expected a SQL command";
			output = false;
		}
		return 0;
	}
	
	//SELECT sentences
	int SELECT_SENTENCE()
	{
		table::sentence = table::SELECT;
		FIELD_LIST();
		if (lexer::token == lexer::FROM)
		{
			lexer::next();
			TABLE_NAME();
			WHERE_CLAUSE();
		}
		else 
		{
			if (output)
				error_message = "Error: expected FROM";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	//INSERT sentences
	int INSERT_SENTENCE()
	{
		table::sentence = table::INSERT;
		table::insert.fields = 1;
		
		if (lexer::token == lexer::INTO)
		{
			lexer::next();
			TABLE_NAME();
			if (lexer::token == lexer::OPEN)
			{
				lexer::next();
				FIELD_VALUE();
				while (lexer::token == lexer::COMMA)
				{
					table::insert.fields++;
					lexer::next();
					FIELD_VALUE();
				}
				if (lexer::token == lexer::CLOSE)
				{
					lexer::next();
				}
				else
				{
					if (output)
						error_message = "Error: expected )";
					lexer::token = lexer::ERROR;
					output = false;
				}
			}
			else
			{
				if (output)
					error_message = "Error: expected (";
				lexer::token = lexer::ERROR;
				output = false;
			}
		}
		else
		{
			if (output)
				error_message = "Error: expected INTO";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	//UPDATE sentences
	int UPDATE_SENTENCE()
	{
		table::sentence = table::UPDATE;
		TABLE_NAME();
		if (lexer::token == lexer::SET)
		{
			lexer::next();
			FIELD_NAME();
			if (lexer::token == lexer::EQUAL)
			{
				lexer::next();
				EXPRESSION();
				WHERE_CLAUSE();
			}
			else 
			{
				if (output)
					error_message = "Error: expected =";
				lexer::token = lexer::ERROR;
				output = false;
			}
		}
		else 
		{
			if (output)
				error_message = "Error: expected SET";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	//DELETE sentences
	int DELETE_SENTENCE()
	{
		table::sentence = table::DELETE;
		if (lexer::token == lexer::FROM)
		{
			lexer::next();
			TABLE_NAME();
			WHERE_CLAUSE();
		}
		else 
		{
			if (output)
				error_message = "Error: expected FROM";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	//CREATE sentences
	int CREATE_SENTENCE()
	{
		table::sentence = table::CREATE;
		table::create.fields = 1;
		
		if (lexer::token == lexer::TABLE)
		{
			lexer::next();
			TABLE_NAME();
			if (lexer::token == lexer::OPEN)
			{
				lexer::next();
				FIELD_DESCRIPTION_LIST();
				if (lexer::token == lexer::CLOSE)
				{
					lexer::next();
				}
				else 
				{
					if (output)
						error_message = "Error: expected )";
					lexer::token = lexer::ERROR;
					output = false;
				}
			}
			else 
			{
				if (output)
					error_message = "Error: expected (";
				lexer::token = lexer::ERROR;
				output = false;
			}
		}
		else 
		{
			if (output)
				error_message = "Error: expected TABLE";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	//DROP sentences
	int DROP_SENTENCE()
	{
		table::sentence = table::DROP;
		if (lexer::token == lexer::TABLE)
		{
			lexer::next();
			TABLE_NAME();
		}
		else 
		{
			if (output)
				error_message = "Error: expected TABLE";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	//EXIT sentences
	int EXIT_SENTENCE()
	{
		table::sentence = table::EXIT;
		lexer::next();
		return 0;
	}
	
	
	int TABLE_NAME()
	{
		if (lexer::token == lexer::IDENT)
		{
			if (table::sentence == table::CREATE)
			{
				table::create.name = new char[lexer::current_text.length()+1];
				strcpy(table::create.name, lexer::current_text.c_str());
			}
			else if (table::sentence == table::INSERT)
			{
				table::insert.name = new char[lexer::current_text.length()+1];
				strcpy(table::insert.name, lexer::current_text.c_str());
			}
			else if (table::sentence == table::DROP)
			{
				table::drop.name = new char[lexer::current_text.length()+1];
				strcpy(table::drop.name, lexer::current_text.c_str());
			}
			else if (table::sentence == table::DELETE)
			{
				table::_delete.name = new char[lexer::current_text.length()+1];
				strcpy(table::_delete.name, lexer::current_text.c_str());
			}
			else if (table::sentence == table::UPDATE)
			{
				table::update.name = new char[lexer::current_text.length()+1];
				strcpy(table::update.name, lexer::current_text.c_str());
			}
			else if (table::sentence == table::SELECT)
			{
				table::select.name = new char[lexer::current_text.length()+1];
				strcpy(table::select.name, lexer::current_text.c_str());
			}
			
			lexer::next();
		}
		else 
		{
			if (output)
				error_message = "Error: expected identificator";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	int FIELD_LIST()
	{
		if (lexer::token == lexer::IDENT)
		{
			table::select.field_list.push_back(lexer::current_text);
			lexer::next();
			while (lexer::token == lexer::COMMA)
			{
				lexer::next();
				if (lexer::token == lexer::IDENT)
				{
					table::select.field_list.push_back(lexer::current_text);
					lexer::next();
				}
				else 
				{
					if (output)
						error_message = "Error: expected identificator";
					lexer::token = lexer::ERROR;
					output = false;
				}
			}
		}
		else if (lexer::token == lexer::MULT)
		{
			table::select.field_list.push_back(lexer::current_text);
			lexer::next();
		}
		else 
		{
			if (output)
				error_message = "Error: expected identificator or *";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	int FIELD_VALUE() 
	{
		if (lexer::token == lexer::STRING || lexer::token == lexer::NUMBER)
		{
			if (table::sentence == table::INSERT)
			{
				table::insert.field_value.push_back(lexer::current_text);
				if (lexer::token == lexer::STRING) 
					table::insert.field_type.push_back(table::STRING);
				else
					table::insert.field_type.push_back(table::LONG);
			}
			
			lexer::next();
		}
		else
		{
			if (output)
				error_message = "Error: expected string or number";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	int FIELD_NAME()  
	{
		if (lexer::token == lexer::IDENT)
		{
			
			if (table::sentence == table::CREATE)
			{
				for (long unsigned iter = 0; iter < lexer::current_text.length(); iter++)
					table::create.field_name[table::create.fields-1][iter] = lexer::current_text[iter];
			}
			else if (table::sentence == table::UPDATE)
			{
				table::update.field_name = lexer::current_text;
			}
			lexer::next();
		}
		else
		{
			if (output)
				error_message = "Error: expected identificator";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	int FIELD_DESCRIPTION_LIST()
	{
		FIELD_DESCRIPTION();
		while (lexer::token == lexer::COMMA)
		{
			table::create.fields++;
			lexer::next();
			FIELD_DESCRIPTION();
		}
		return 0;
	}
	
	int FIELD_DESCRIPTION()
	{
		FIELD_NAME();
		FIELD_TYPE();
		return 0;
	}
	
	int FIELD_TYPE()
	{
		if (lexer::token == lexer::TEXT)
		{
			table::create.field_type.push_back(table::TEXT);
			lexer::next();
			if (lexer::token == lexer::OPEN)
			{
				lexer::next();
				if (lexer::token == lexer::NUMBER)
				{
					table::create.field_size.push_back(std::stoi(lexer::current_text));
					lexer::next();
					if (lexer::token == lexer::CLOSE)
					{
						lexer::next();
					}
					else 
					{
						error_message = "Error: expected )";
						lexer::token = lexer::ERROR;
						output = false;
					}
				}
				else 
				{
					if (output)
						error_message = "Error: expected number";
					lexer::token = lexer::ERROR;
					output = false;
				}
			}
			else 
			{
				if (output)
					error_message = "Error: expected (";
				lexer::token = lexer::ERROR;
				output = false;
			}
		}
		else if (lexer::token == lexer::LONG)
		{
			if (table::sentence == table::CREATE)
			{
				table::create.field_type.push_back(table::LONG);
				table::create.field_size.push_back(12);
			}
			lexer::next();
		}
		else 
		{
			if (output)
				error_message = "Error: expected LONG or TEXT";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	int EXPRESSION() 
	{
		if (lexer::token == lexer::STRING)
		{
			table::update.expr_type = table::STRING;
			table::update.expr.push_back(lexer::current_text);
			
			lexer::next();
		}
		else
		{
			int output = 0;
			output += LONG_ADD();
			while (lexer::token == lexer::PLUS || lexer::token == lexer::MINUS)
			{
				table::update.expr_type = table::LONG;
				table::update.expr.push_back(lexer::current_text);
				if (lexer::token == lexer::PLUS)
				{
					lexer::next();
					output += LONG_ADD();
				}
				else 
				{
					lexer::next();
					output -= LONG_ADD();
				}
			}
			return output;
		}
		return 0;
	}
	
	int LONG_EXPRESSION() 
	{
		int output = 0;
		output += LONG_ADD();
		while (lexer::token == lexer::PLUS || lexer::token == lexer::MINUS)
		{
			table::update.expr_type = table::LONG;
			table::update.expr.push_back(lexer::current_text);
			if (lexer::token == lexer::PLUS)
			{
				lexer::next();
				output += LONG_ADD();
			}
			else 
			{
				lexer::next();
				output -= LONG_ADD();
			}
		}
		return output;
	}
	
	int LONG_ADD()
	{
		int output = 1;
		output *= LONG_MULT();
		while (lexer::token == lexer::MULT || lexer::token == lexer::DIV || lexer::token == lexer::PERCENT)
		{
			table::update.expr_type = table::LONG;
			table::update.expr.push_back(lexer::current_text);
			if (lexer::token == lexer::MULT)
			{
				lexer::next();
				output *= LONG_MULT();
			}
			else if (lexer::token == lexer::DIV)
			{
				lexer::next();
				output /= LONG_MULT();
			}
			else 
			{
				lexer::next();
				output %= LONG_MULT();
			}
		}
		return output;
	}
	
	int LONG_MULT()
	{
		int output = 0;
		if (lexer::token == lexer::IDENT)
		{
			table::update.expr.push_back(lexer::current_text);
			lexer::next();
			
		}
		else if (lexer::token == lexer::NUMBER)
		{
			table::update.expr_type = table::LONG;
			table::update.expr.push_back(lexer::current_text);
			output = std::stoi(lexer::current_text);
			lexer::next();
			return output;
		}
		else if (lexer::token == lexer::OPEN)
		{
			table::update.expr.push_back(lexer::current_text);
			lexer::next();
			output = LONG_EXPRESSION();
			if (lexer::token == lexer::CLOSE)
			{
				table::update.expr.push_back(lexer::current_text);
				lexer::next();
				return output;
			}
			else 
			{
				if (output)
					error_message = "Error: incorrect expression";
				lexer::token = lexer::ERROR;
				output = false;
			}
		}
		else 
		{
			if (output)
				error_message = "Error: incorrect expression";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	int WHERE_CLAUSE()
	{
		if (lexer::token == lexer::WHERE)
		{
			
			
			look_ahead.push_back(lexer::token);
			look_ahead_text.push_back(lexer::current_text);
			while (lexer::token != lexer::END)
			{
				lexer::next();
				look_ahead.push_back(lexer::token);
				look_ahead_text.push_back(lexer::current_text);
			}
			
			
			i++;
			if (look_ahead[i] == lexer::ALL)
			{
				table::where_clause = table::ALL;
				i++;
			}
			else if (std::find(std::begin(look_ahead), std::end(look_ahead), lexer::LIKE) != std::end(look_ahead))
			{
		
				table::where_clause = table::LIKE;
			
				
				
				TEXT_FIELD_NAME();
				if (look_ahead[i] == lexer::NOT)
				{
					table::where_not = true;
					i++;
				}
				if (look_ahead[i] == lexer::LIKE)
				{
					i++;
					STRING_SAMPLE();
				}
				else 
				{
					if (output)
						error_message = "Error: LIKE is in a wrong place";
					lexer::token = lexer::ERROR;
					output = false;
				}
			}
			else if (std::find(std::begin(look_ahead), std::end(look_ahead), lexer::IN) != std::end(look_ahead))
			{
				
				
				table::where_clause = table::IN;
				
				
				
				
				WHERE_EXPRESSION();
				if (look_ahead[i] == lexer::NOT)
				{
					table::where_not = true;
					i++;
				}
				if (look_ahead[i] == lexer::IN)
				{
					i++;
					if (look_ahead[i] == lexer::OPEN)
					{
						i++;
						VALUE_LIST();
						if (look_ahead[i] == lexer::CLOSE)
						{
							i++;
						}
						else 
						{
							if (output)
								error_message = "Error: expected )";
							lexer::token = lexer::ERROR;
							output = false;
						}
					}
					else 
					{
						if (output)
							error_message = "Error: expected (";
						lexer::token = lexer::ERROR;
						output = false;
					}
				}
				else 
				{
					if (output)
						error_message = "Error: IN is in a wrong place";
					lexer::token = lexer::ERROR;
					output = false;
				}
			}
			else 
			{
				table::where_clause = table::BOOL;
				BOOL_EXPRESSION();
			}
			if (look_ahead[i] != lexer::END)
			{
				if (output)
					error_message = "Error: excess text after the sentence";
				lexer::token = lexer::ERROR;
				output = false;
			}
		}
		else 
		{
			if (output)
				error_message = "Error: expected WHERE";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	int TEXT_FIELD_NAME()
	{
		if (look_ahead[i] == lexer::IDENT)
		{
			table::where_like_field = look_ahead_text[i];
			i++;
		}
		else 
		{
			if (output)
				error_message = "Error: expected identificator of a text field";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	int STRING_SAMPLE()
	{
		if (look_ahead[i] == lexer::STRING)
		{
			table::where_like_sample = look_ahead_text[i];
			i++;
		}
		else 
		{
			if (output)
				error_message = "Error: expected string";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	int VALUE_LIST()
	{
		if (look_ahead[i] == lexer::STRING)
		{
			table::where_in_constlist_type = table::TEXT;
			table::where_in_constlist.push_back(look_ahead_text[i]);
			i++;
			while (look_ahead[i] == lexer::COMMA)
			{
				i++;
				if (look_ahead[i] == lexer::STRING)
				{
					table::where_in_constlist.push_back(look_ahead_text[i]);
					i++;
				}
				else 
				{
					if (output)
						error_message = "Error: expected string";
					lexer::token = lexer::ERROR;
					output = false;
				}
			}
		}
		else if (look_ahead[i] == lexer::NUMBER)
		{
			table::where_in_constlist_type = table::LONG;
			table::where_in_constlist.push_back(look_ahead_text[i]);
			i++;
			while (look_ahead[i] == lexer::COMMA)
			{
				i++;
				if (look_ahead[i] == lexer::NUMBER)
				{
					table::where_in_constlist.push_back(look_ahead_text[i]);
					i++;
				}
				else 
				{
					if (output)
						error_message = "Error: expected number";
					lexer::token = lexer::ERROR;
					output = false;
				}
			}
		}
		else 
		{
			if (output)
				error_message = "Error: expected string or number";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	
	int WHERE_EXPRESSION()
	{
		if (look_ahead[i] == lexer::STRING)
		{
			table::where_in_expr_type = table::STRING;
			table::where_in_expr.push_back(look_ahead_text[i]);
			i++;
		}
		else 
		{
			table::where_in_expr_type = table::TEXT;
			WHERE_LONG_EXPRESSION();
		}
		return 0;
	}
	
	int WHERE_LONG_EXPRESSION()
	{
		WHERE_LONG_ADD();
		while (look_ahead[i] == lexer::PLUS || look_ahead[i] == lexer::MINUS)
		{
			table::where_in_expr_type = table::LONG;
			table::where_in_expr.push_back(look_ahead_text[i]);
			table::where_bool_expr.push_back(look_ahead_text[i]);
			if (look_ahead[i] == lexer::PLUS)
			{
				i++;
				WHERE_LONG_ADD();
			}
			else
			{
				i++;
				WHERE_LONG_ADD();
			}
		}
		return 0;
	}
	
	int WHERE_LONG_ADD()
	{
		WHERE_LONG_MULT();
		while (look_ahead[i] == lexer::MULT || look_ahead[i] == lexer::DIV || look_ahead[i] == lexer::PERCENT)
		{
			table::where_in_expr_type = table::LONG;
			table::where_in_expr.push_back(look_ahead_text[i]);
			table::where_bool_expr.push_back(look_ahead_text[i]);
			if (look_ahead[i] == lexer::MULT)
			{
				i++;
				WHERE_LONG_MULT();
			}
			else if (look_ahead[i] == lexer::DIV)
			{
				i++;
				WHERE_LONG_MULT();
			}
			else
			{
				i++;
				WHERE_LONG_MULT();
			}
		}
		return 0;
	}
	
	int WHERE_LONG_MULT()
	{
		if (look_ahead[i] == lexer::NUMBER || look_ahead[i] == lexer::IDENT)
		{
			if (look_ahead[i] == lexer::NUMBER)
			{
				table::where_in_expr_type = table::LONG;
			}
			table::where_in_expr.push_back(look_ahead_text[i]);
			table::where_bool_expr.push_back(look_ahead_text[i]);
			i++;
		}
		else if (look_ahead[i] == lexer::OPEN)
		{
			table::where_in_expr.push_back(look_ahead_text[i]);
			table::where_bool_expr.push_back(look_ahead_text[i]);
			i++;
			WHERE_LONG_EXPRESSION();
			if (look_ahead[i] == lexer::CLOSE)
			{
				table::where_in_expr.push_back(look_ahead_text[i]);
				table::where_bool_expr.push_back(look_ahead_text[i]);
				i++;
			}
			else 
			{
				if (output)
					error_message = "Error: incorrect expression";
				lexer::token = lexer::ERROR;
				output = false;
			}
		}
		else 
		{
			if (output)
				error_message = "Error: incorrect expression";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	
	
	int BOOL_EXPRESSION()
	{
		BOOL_ADD();
		while (look_ahead[i] == lexer::OR)
		{
			table::where_bool_expr.push_back(look_ahead_text[i]);
			i++;
			BOOL_ADD();
		}
		return 0;
	}
	
	int BOOL_ADD()
	{
		BOOL_MULT();
		while (look_ahead[i] == lexer::AND)
		{
			table::where_bool_expr.push_back(look_ahead_text[i]);
			i++;
			BOOL_MULT();
		}
		return 0;
	}
	
	int BOOL_MULT() 
	{
		if (look_ahead[i] == lexer::NOT)
		{
			table::where_bool_expr.push_back(look_ahead_text[i]);
			i++;
			BOOL_MULT();
		}
		else if (look_ahead[i] == lexer::OPEN) 
		{
			table::where_bool_expr.push_back(look_ahead_text[i]);
			i++;
			if (look_ahead[i] == lexer::NOT)
			{
				BOOL_EXPRESSION();
				if (look_ahead[i] == lexer::CLOSE) 
				{
					table::where_bool_expr.push_back(look_ahead_text[i]);
					i++;
				}
				else
				{	
					if (output)
						error_message = "Error: incorrect bool expression";
					lexer::token = lexer::ERROR;
					output = false;
				}
			}
			else if (look_ahead[i] == lexer::IDENT || look_ahead[i] == lexer::NUMBER || look_ahead[i] == lexer::STRING)
			{
				COMPARISON();
				if (look_ahead[i] == lexer::CLOSE)
				{
					table::where_bool_expr.push_back(look_ahead_text[i]);
					i++;
				}
				else
				{	
					if (output)
						error_message = "Error: incorrect bool expression";
					lexer::token = lexer::ERROR;
					output = false;
				}
			}
			else if (look_ahead[i] == lexer::OPEN) 
			{
				int flag = 0;
				int j = i;
				int balance = 2;
				
				while (balance != 0)
				{
					j++;
					
					if (look_ahead[j] == lexer::CLOSE)
					{
						balance--;
					}
					else if (look_ahead[j] == lexer::OPEN)
					{
						balance++;
					}
					else if (look_ahead[j] == lexer::AND || look_ahead[j] == lexer::OR || look_ahead[j] == lexer::NOT)
					{
						flag++;
						break;
					}
					else if (look_ahead[j] == lexer::END)
					{
						if (output)
							error_message = "Error: incorrect bool expression";
						lexer::token = lexer::ERROR;
						output = false;
						break;
					}
					
				}
				if (flag)
				{
					BOOL_EXPRESSION();
				}
				else 
				{
					COMPARISON();
				}
				if (look_ahead[i] == lexer::CLOSE)
				{
					table::where_bool_expr.push_back(look_ahead_text[i]);
					i++;
				}
				else
				{
					if (output)
						error_message = "Error: incorrect bool expression";
					lexer::token = lexer::ERROR;
					output = false;
				}
				
			}
			else
			{
				if (output)
					error_message = "Error: incorrect bool expression";
				lexer::token = lexer::ERROR;
				output = false;
			}
		}
		else
		{
			if (output)
				error_message = "Error: expected ( or NOT";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	int COMPARISON()
	{
		if (look_ahead[i] == lexer::STRING)
		{
			table::where_bool_expr.push_back(look_ahead_text[i]);
			i++;
			SIGN_COMP();
			if (look_ahead[i] == lexer::STRING || look_ahead[i] == lexer::IDENT)
			{
				table::where_bool_expr.push_back(look_ahead_text[i]);
				i++;
			}
			else
			{
				if (output)
					error_message = "Error: incorrect bool expression";
				lexer::token = lexer::ERROR;
				output = false;
			}
			
		}
		else if (look_ahead[i] == lexer::IDENT && look_ahead[i+1] >= lexer::EQUAL && look_ahead[i+1] <= lexer::SOFT_LESSER && (look_ahead[i+2] == lexer::IDENT || look_ahead[i+2] == lexer::STRING))
		{
			table::where_bool_expr.push_back(look_ahead_text[i]);
			i++;
			table::where_bool_expr.push_back(look_ahead_text[i]);
			i++;
			table::where_bool_expr.push_back(look_ahead_text[i]);
			i++;
		}
		
		else if (look_ahead[i] == lexer::OPEN)
		{
			int flag = 0;
			int j = i;
			int balance = 2;
				
			while (balance != 0)
			{
				j++;
				
				if (look_ahead[j] == lexer::CLOSE)
				{
					balance--;
				}
				else if (look_ahead[j] == lexer::OPEN)
				{
					balance++;
				}
				else if (look_ahead[j] == lexer::EQUAL || look_ahead[j] == lexer::NOT_EQUAL || look_ahead[j] == lexer::LESSER
				|| look_ahead[j] == lexer::GREATER || look_ahead[j] == lexer::SOFT_LESSER || look_ahead[j] == lexer::SOFT_GREATER)
				{
					flag++;
					break;
				}
				else if (look_ahead[j] == lexer::END)
				{
					if (output)
						error_message = "Error: incorrect bool expression";
					lexer::token = lexer::ERROR;
					output = false;
					break;
				}
					
			}
			if (flag)
			{
				table::where_bool_expr.push_back(look_ahead_text[i]);
				i++;
				COMPARISON();
				if (look_ahead[i] == lexer::CLOSE)
				{
					table::where_bool_expr.push_back(look_ahead_text[i]);
					i++;
				}
				else
				{
					if (output)
						error_message = "Error: incorrect bool expression";
					lexer::token = lexer::ERROR;
					output = false;
				}
			}
			else 
			{
				WHERE_LONG_EXPRESSION();
				SIGN_COMP();
				WHERE_LONG_EXPRESSION();
			}
			
		}
		else 
		{
			WHERE_LONG_EXPRESSION();
			SIGN_COMP();
			WHERE_LONG_EXPRESSION();
		}
		return 0;
	}
	
	int SIGN_COMP()
	{
		if (look_ahead[i] >= lexer::EQUAL && look_ahead[i] <= lexer::SOFT_LESSER)
		{
			table::where_bool_expr.push_back(look_ahead_text[i]);
			i++;
		}
		else
		{
			if (output)
				error_message = "Error: expected a comparison sign";
			lexer::token = lexer::ERROR;
			output = false;
		}
		return 0;
	}
	
	long CalculateExpression(THandle*, std::vector <std::string>&, int&);
	long CalculateAddendum(THandle*, std::vector <std::string>&, int&);
	long CalculateMultiplier(THandle*, std::vector <std::string>&, int&);
	bool CalculateBoolExpression(THandle*, std::vector <std::string>&, int&);
	bool CalculateBoolAddendum(THandle*, std::vector <std::string>&, int&);
	bool CalculateBoolMultiplier(THandle*, std::vector <std::string>&, int&);
	bool CalculateComparison(THandle*, std::vector <std::string>&, int&);
	
	
	long CalculateExpression(THandle *tableHandle, std::vector <std::string> &expr, int &j)
	{
		//We have expression in expr
		int out = 0;
		out += CalculateAddendum(tableHandle, expr, j);
		while (expr[j] == "+" || expr[j] == "-")
		{
			if (expr[j] == "+")
			{
				j++;
				out += CalculateAddendum(tableHandle, expr, j);
			}
			else if (expr[j] == "-")
			{
				j++;
				out -= CalculateAddendum(tableHandle, expr, j);
			}
		}
		return out;
	}
	
	long CalculateAddendum(THandle *tableHandle, std::vector <std::string> &expr, int &j)
	{
		
		//We have expression in expr
		int out = 1;
		out *= CalculateMultiplier(tableHandle, expr, j);
		while (expr[j] == "*" || expr[j] == "/" || expr[j] == "%")
		{
			if (expr[j] == "*")
			{
				j++;
				out *= CalculateMultiplier(tableHandle, expr, j);
			}
			else if (expr[j] == "/")
			{
				j++;
				out /= CalculateMultiplier(tableHandle, expr, j);
			}
			else if (expr[j] == "%")
			{
				j++;
				out %= CalculateMultiplier(tableHandle, expr, j);
			}
		}
		return out;
		
	}
	
	long CalculateMultiplier(THandle *tableHandle, std::vector <std::string> &expr, int &j)
	{
		int out = 0;
		
		if (expr[j] == "(")
		{
			j++;
			out = CalculateExpression(tableHandle, expr, j);
			j++;
		}
		else
		{
			int convert;
			try
			{
				convert = std::stoi(expr[j]);
				out = convert;
			}
			catch(...)
			{
				long field;
				getLong(*tableHandle, (char*)(unsigned long)expr[j].c_str(), &field);
				out = field;
			}
			if (j != expr.size() - 1)
				j++;
		}
		return out;
	}
	
	
	bool CalculateBoolExpression(THandle *tableHandle, std::vector <std::string> &expr, int &j)
	{
		
		bool out = false;
		out = out || CalculateBoolAddendum(tableHandle, expr, j);
		while (expr[j] == "OR")
		{
			
			j++;
			out = out || CalculateBoolAddendum(tableHandle, expr, j);
		}
		return out;

	}
	bool CalculateBoolAddendum(THandle *tableHandle, std::vector <std::string> &expr, int &j)
	{
		bool out = true;
		out = out && CalculateBoolMultiplier(tableHandle, expr, j);
		while (expr[j] == "AND")
		{
			j++;
			out = out && CalculateBoolMultiplier(tableHandle, expr, j);
		}
		return out;
	}
	bool CalculateBoolMultiplier(THandle *tableHandle, std::vector <std::string> &expr, int &j)
	{
		bool out = false;
		bool inverse = false;
		while (expr[j] == "NOT")
		{
			inverse = not inverse;
			j++;
		}
		
		//Here expr[j] == "("
		int balance = 1;
		int k = j;
		int flag = 0;
		while (balance != 0)
		{
			k++;
			if (expr[k] == "AND" || expr[k] == "OR" || expr[k] == "NOT")
			{
				flag = 1;
				break;
			}
			else if (expr[k] == "(")
			{
				balance++;
			}
			else if (expr[k] == ")")
			{
				balance--;
			}
		}
		if (flag)
		{
			
			out = CalculateBoolExpression(tableHandle, expr, j);
		}
		else
		{
			
			out = CalculateComparison(tableHandle, expr, j);
		}
		
		if (!inverse)
			return out;
		else
			return not out;
		
	}
	bool CalculateComparison(THandle *tableHandle, std::vector <std::string> &expr, int &j)
	{
		
		bool out;
		int k = j;
		int surround = 1;
		while (expr[k] != "=" && expr[k] != "!=" && expr[k] != ">" && expr[k] != "<" 
	    && expr[k] != ">=" && expr[k] != "<=")
		{
			k++;
			if (expr[k] == "(")
			{
				surround++;
			}
			else if (expr[k] == ")")
			{
				surround--;
			}
		}
		
		//surround has the amount of hugging paranthesis
		for (int iter = 0; iter < surround; iter++)
			j++;
		
		//Here we have long or text expression
		FieldType ft;
		if (getFieldType(*tableHandle, (char*)(unsigned long)expr[j].c_str(), &ft) == 0)
		{
			if (ft == Text)
			{
				//First operand is text field name
				char **field1 = new char*;
				char **field2 = new char*;
				std::string compare;
				int cmp;
				
				getText(*tableHandle, (char*)(unsigned long)expr[j].c_str(), field1);
				j++;
				compare = expr[j];
				j++;
				if (getFieldType(*tableHandle, (char*)(unsigned long)expr[j].c_str(), &ft) == 0)
				{
					if (ft == Text)
					{
						
						getText(*tableHandle, (char*)(unsigned long)expr[j].c_str(), field2);
						cmp = strcmp(*field1, *field2);
						if (compare == "=")
							out = cmp == 0;
						else if (compare == "!=")
							out = cmp != 0;
						else if (compare == ">")
							out = cmp > 0;
						else if (compare == "<")
							out = cmp < 0;
						else if (compare == ">=")
							out = cmp >= 0;
						else if (compare == "<=")
							out = cmp <= 0;
					}
					else out = false;
				}
				else if (expr[j][0] == '\'')
				{
					expr[j].pop_back();
					expr[j].erase(expr[j].begin());
					cmp = strcmp(*field1, (char*)(unsigned long)expr[j].c_str());
					expr[j].push_back('\'');
					expr[j].insert(expr[j].begin(), '\'');
					if (compare == "=")
						out = cmp == 0;
					else if (compare == "!=")
						out = cmp != 0;
					else if (compare == ">")
						out = cmp > 0;
					else if (compare == "<")
						out = cmp < 0;
					else if (compare == ">=")
						out = cmp >= 0;
					else if (compare == "<=")
						out = cmp <= 0;
				}
				else out = false;
				
				j++;
				delete field1;
				delete field2;
			}
			else 
			{
				//First operand is long expression
				long operand1, operand2;
				std::string compare;
				operand1 = CalculateExpression(tableHandle, expr, j);
				compare = expr[j];
				j++;
				operand2 = CalculateExpression(tableHandle, expr, j);
				
				if (compare == "=")
					out = operand1 == operand2;
				else if (compare == "!=")
					out = operand1 != operand2;
				else if (compare == ">")
					out = operand1 > operand2;
				else if (compare == "<")
					out = operand1 < operand2;
				else if (compare == ">=")
					out = operand1 >= operand2;
				else if (compare == "<=")
					out = operand1 <= operand2;
				
			}
		}
		else if (expr[j][0] == '\'')
		{
			//First operand is string
			int cmp;
			std::string compare;
			expr[j].pop_back();
			expr[j].erase(expr[j].begin());
			j++;
			compare = expr[j];
			j++;
			
			FieldType ft;
			if (getFieldType(*tableHandle, (char*)(unsigned long)expr[j].c_str(), &ft) == 0)
			{
				if (ft == Text)
				{
					char **field = new char*;
					
					getText(*tableHandle, (char*)(unsigned long)expr[j].c_str(), field);
					cmp = strcmp((char*)(unsigned long)expr[j-2].c_str(), *field);
					if (compare == "=")
						out = cmp == 0;
					else if (compare == "!=")
						out = cmp != 0;
					else if (compare == ">")
						out = cmp > 0;
					else if (compare == "<")
						out = cmp < 0;
					else if (compare == ">=")
						out = cmp >= 0;
					else if (compare == "<=")
						out = cmp <= 0;
					
					delete field;
				}
				else out = false;
			}
			else if (expr[j][0] == '\'')
			{
				expr[j].pop_back();
				expr[j].erase(expr[j].begin());
				cmp = strcmp((char*)(unsigned long)expr[j-2].c_str(), (char*)(unsigned long)expr[j].c_str());
				expr[j].push_back('\'');
				expr[j].insert(expr[j].begin(), '\'');
				if (compare == "=")
					out = cmp == 0;
				else if (compare == "!=")
					out = cmp != 0;
				else if (compare == ">")
					out = cmp > 0;
				else if (compare == "<")
					out = cmp < 0;
				else if (compare == ">=")
					out = cmp >= 0;
				else if (compare == "<=")
					out = cmp <= 0;
			}
			else out = false;
			expr[j-2].push_back('\'');
			expr[j-2].insert(expr[j-2].begin(), '\'');
			j++;
		}
		else 
		{
			//First operand is long expression
			
			long operand1, operand2;
			std::string compare;
			operand1 = CalculateExpression(tableHandle, expr, j);
			compare = expr[j];
			j++;
			operand2 = CalculateExpression(tableHandle, expr, j);
			
			if (compare == "=")
				out = operand1 == operand2;
			else if (compare == "!=")
				out = operand1 != operand2;
			else if (compare == ">")
				out = operand1 > operand2;
			else if (compare == "<")
				out = operand1 < operand2;
			else if (compare == ">=")
				out = operand1 >= operand2;
			else if (compare == "<=")
				out = operand1 <= operand2;
			
		}
		
		for (int iter = 0; iter < surround; iter++)
			j++;
		return out;
		
	}
	
}