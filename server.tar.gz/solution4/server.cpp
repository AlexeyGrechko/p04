#include "socketlib.hpp"
#include "lexlib.hpp"

int main()
{
    int listener, client, listener2, client2;
    const char *c = "socket.txt";
    const char *c2 = "socket2.txt";
    char *buf = new char[100];
    char cur;
    const char* reply = "Connection established";
    bool do_delete = true;
    
    listener = CreateListenerSocket(c);

    
for (;;)
{
        output = true;
        client = accept(listener, NULL, NULL);
        send (client, reply, strlen(reply), 0);
        dup2(client, 0);
        
        //Here we can start the analysis
        
        
        //  SYNTAX CHECK
        
        
        lexer::init();
        lexer::next();
        parser::START();
        if (lexer::token != lexer::END)
        {
            output = false;
            while (lexer::token != lexer::END)
                lexer::next();
        }
        
    
    
    // ___EXECUTING COMMANDS___
    if (output)
    {
        do_delete = false;
        
        //CREATE TABLE
        if (table::sentence == table::CREATE)
        {
            cout << table::create.name << " created" << endl;
        
            struct TableStruct t_struct;
            t_struct.numOfFields = table::create.fields;
            struct FieldDef *fd = new FieldDef[table::create.fields];
            for (int i = 0; i < table::create.fields; i++)
            {
                strcpy(fd[i].name, table::create.field_name[i]);
                if (table::create.field_type[i] == table::TEXT)
                    fd[i].type = Text;
                else
                    fd[i].type = Long;
                fd[i].len = table::create.field_size[i];
            }
            t_struct.fieldsDef = fd;
        
            char *t_name = new char[50]; 
            strcpy(t_name,table::create.name);
            createTable(t_name, &t_struct);
        
            delete []t_name;
            delete []fd;
            
            delete []table::create.name;
        }
        
        
        
        //INSERT INTO TABLE
        else if (table::sentence == table::INSERT)
        {
            
            char **field = new char*;
            unsigned len;
            char *t_name = new char[50]; 
            THandle tableHandle;
            enum FieldType *ft = new FieldType;
            *ft = Long;
            
            
            strcpy(t_name,table::insert.name);
            if(openTable(t_name, &tableHandle) == 0)
            {
                getFieldsNum(tableHandle, &len);
                if (len == table::insert.fields)
                {
                    for (unsigned i = 0; i < table::insert.fields; i++)
                    {
                        getFieldName(tableHandle, i, field);
                        getFieldType(tableHandle, *field, ft);
                        if ((*ft == Long) && (table::insert.field_type[i] != table::LONG)
                            ||(*ft == Text) && (table::insert.field_type[i] != table::STRING))
                            {
                                output = false;
                                error_message = "Error: parameters in INSERT don't fit the table";
                            }
                            
                    }
                    if (output)
                    {
                        for (unsigned i = 0; i < table::insert.fields; i++)
                        {
                            getFieldName(tableHandle, i, field);
                            getFieldType(tableHandle, *field, ft);
                        
                            if (*ft == Long)
                            {
                                createNew(tableHandle);
                                putLongNew(tableHandle, *field, std::stoi(table::insert.field_value[i]));
                                insertzNew(tableHandle);
                            }
                            else if (*ft == Text)
                            {
                                createNew(tableHandle);
                                table::insert.field_value[i].pop_back();
                                table::insert.field_value[i].erase(table::insert.field_value[i].begin());
                                char *help = new char[50];
                                putTextNew(tableHandle, *field, (char*)(unsigned long)table::insert.field_value[i].c_str());
                                insertzNew(tableHandle);
                                delete []help;
                            }
                        }
                    }
                }
                else 
                {
                    error_message = "Error: parameters in INSERT don't fit the table";
                    output = false;
                }
            }
            else 
            {
                error_message = "Error: bad file name in INSERT";
                output = false;
            }
            
            
            
            closeTable(tableHandle);
            delete []t_name;
            delete field;
            delete ft;
            
            delete []table::insert.name;
        }
        
        
        //DROP TABLE
        else if (table::sentence == table::DROP)
        {
            
            if(deleteTable(table::drop.name))
            {
                error_message = "Error: bad file name in DROP";
                output = false;
            }
            else 
            {
                cout << table::drop.name << " dropped" << endl;
            }
            
            delete []table::drop.name;
        }
    
        
        //DELETE RECORD FROM TABLE
        else if (table::sentence == table::DELETE)
        {
            char *t_name = new char[50]; 
            THandle tableHandle;
            strcpy(t_name,table::_delete.name);
            
            
            
            //Checking if table exists
            if (openTable(t_name, &tableHandle) == 0)
            {
                unsigned int fields;
                std::vector <std::vector <std::string> >  selected_fields;
                getFieldsNum(tableHandle, &fields);
                for (unsigned i = 0; i < fields; i++)
                {
                    char **field = new char*;
                    getFieldName(tableHandle, i, field);
                    table::_delete.field_list.push_back(*field);
                    delete field;
                }
            
                
            
                
                //Finally can start selecting!
                
                //WHERE clause == WHERE ALL 
                if (table::where_clause == table::ALL)
                {
                    selected_fields.clear();
                    
                    
                    
                    
                    
                }
                
                //WHERE clause == WHERE ... LIKE ...
                else if (table::where_clause == table::LIKE)
                {
                    FieldType ftype;
                    
                    
                    //Does field in WHERE clause exist?
                    if(getFieldType(tableHandle, (char*)(unsigned long)table::where_like_field.c_str(), &ftype) == 0)
                    {
                        
                        if (ftype == Text)
                        {
                            table::where_like_sample.pop_back();
                            table::where_like_sample.erase(table::where_like_sample.begin());
                            
                            while (!afterLast(tableHandle))
                            {
                                int flag = 0;
                                
                                for (unsigned i = 0; i < fields; i++)
                                {
                                    
                                    char **field = new char*;
                                    getText(tableHandle, (char*)(unsigned long)table::where_like_field.c_str(), field);
                                    
                                    if (strcmp(*field, table::where_like_sample.c_str()) == 0)
                                    {
                                        flag = 1;
                                    }
                                    
                                    moveNext(tableHandle);
                                    delete field;
                    
                                }
                                
                                for (unsigned i = 0; i < fields; i++)
                                    movePrevios(tableHandle);
                                
                                if (table::where_not) flag = (flag+1)%2;
                                if (!flag)
                                {
                                    std::vector <std::string> cur_select;
                                    for (long unsigned i = 0; i < table::_delete.field_list.size(); i++)
                                    {
                                        
                                        FieldType cur_ft;
                                        
                                        getFieldType(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), &cur_ft);
                                        for (unsigned j = 0; j < fields; j++)
                                        {
                                            char **field = new char*;
                                            
                                            getFieldName(tableHandle, j, field);
                                            if (strcmp(*field, (char*)(unsigned long)table::_delete.field_list[i].c_str()) == 0)
                                            {
                                                //Push back text field 
                                                if (cur_ft == Text)
                                                {
                                                    char **field = new char*;
                                            
                                                    getText(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), field);
                                                    cur_select.push_back(*field);
                                            
                                                    delete field;
                                                }
                                                //Push back long field
                                                else 
                                                {
                                                    long field;
                                            
                                                    getLong(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), &field);
                                                    cur_select.push_back(std::to_string(field));
                                            
                                                }
                                            }
                                            
                                            delete field;
                                            moveNext(tableHandle);
                                        }
                                        for (unsigned j = 0; j < fields; j++)
                                        {
                                            movePrevios(tableHandle);
                                        }
                                    }
                                    selected_fields.push_back(cur_select);
                                    for (unsigned j = 0; j < fields; j++)
                                    {
                                        moveNext(tableHandle);
                                    }
                                }
                                else
                                {
                                    for (unsigned i = 0; i < fields; i++)
                                        moveNext(tableHandle);
                                }
                                
                                
                            }
                        }
                        else 
                        {
                            error_message = "Error: field name in WHERE clause must be of TEXT type";
                            output = false;
                        }
                    }
                    else
                    {
                        error_message = "Error: non-existing field name in WHERE clause";
                        output = false;
                    }
                    
                    
                }
                
                //WHERE clause == WHERE ... IN ...
                else if (table::where_clause == table::IN)
                {
                    table::where_in_expr.push_back(" ");
                    if (table::where_in_constlist_type == table::TEXT)
                    {
                        
                        if (table::where_in_expr[0][0] == '\'')
                        {
                            //Expression is string
                            //Just search through the const list
                            int flag = 0;
                            for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                            {
                                if (table::where_in_constlist[i] == table::where_in_expr[0])
                                {
                                    flag = 1;
                                }
                            }
                            if (table::where_not) flag = (flag+1)%2;
                            if (!flag)
                            {
                                while (!afterLast(tableHandle))
                                {
                                    std::vector <std::string> cur_select;
                                    for (long unsigned i = 0; i < table::_delete.field_list.size(); i++)
                                    {
                                        
                                        FieldType cur_ft;
                                        
                                        getFieldType(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), &cur_ft);
                                        for (unsigned j = 0; j < fields; j++)
                                        {
                                            char **field = new char*;
                                            
                                            getFieldName(tableHandle, j, field);
                                            if (strcmp(*field, (char*)(unsigned long)table::_delete.field_list[i].c_str()) == 0)
                                            {
                                                //Push back text field 
                                                if (cur_ft == Text)
                                                {
                                                    char **field = new char*;
                                            
                                                    getText(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), field);
                                                    cur_select.push_back(*field);
                                            
                                                    delete field;
                                                }
                                                //Push back long field
                                                else 
                                                {
                                                    long field;
                                            
                                                    getLong(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), &field);
                                                    cur_select.push_back(std::to_string(field));
                                            
                                                }
                                            }
                                            
                                            delete field;
                                            moveNext(tableHandle);
                                        }
                                        for (unsigned j = 0; j < fields; j++)
                                        {
                                            movePrevios(tableHandle);
                                        }
                                    }
                                    selected_fields.push_back(cur_select);
                                    for (unsigned j = 0; j < fields; j++)
                                    {
                                        moveNext(tableHandle);
                                    }
                                }
                            }
                        }
                        else 
                        {
                            //Expression is text field name
                            
                            FieldType ft;
                            if (getFieldType(tableHandle, (char*)(unsigned long)table::where_in_expr[0].c_str(), &ft) == 0)
                            {
                                if (ft == Text)
                                {
                                    
                                    for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                                    {
                                        table::where_in_constlist[i].pop_back();
                                        table::where_in_constlist[i].erase(table::where_in_constlist[i].begin());
                                    }
                                    
                                    while (!afterLast(tableHandle))
                                    {
                                        int flag = 0;
                                        
                                        for (unsigned i = 0; i < fields; i++)
                                        {
                                            
                                            char **field = new char*;
                                            getText(tableHandle, (char*)(unsigned long)table::where_in_expr[0].c_str(), field);
                                            for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                                            {
                                                if (strcmp(*field, table::where_in_constlist[i].c_str()) == 0)
                                                {
                                                    flag = 1;
                                                }
                                            }
                                            
                                            
                                            moveNext(tableHandle);
                                            delete field;
                            
                                        }
                                        
                                        for (unsigned i = 0; i < fields; i++)
                                            movePrevios(tableHandle);
                                        
                                        if (table::where_not) flag = (flag+1)%2;
                                        if (!flag)
                                        {
                                            
                                            std::vector <std::string> cur_select;
                                            for (long unsigned i = 0; i < table::_delete.field_list.size(); i++)
                                            {
                                                
                                                FieldType cur_ft;
                                                
                                                getFieldType(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), &cur_ft);
                                                for (unsigned j = 0; j < fields; j++)
                                                {
                                                    char **field = new char*;
                                                    
                                                    getFieldName(tableHandle, j, field);
                                                    if (strcmp(*field, (char*)(unsigned long)table::_delete.field_list[i].c_str()) == 0)
                                                    {
                                                        //Push back text field 
                                                        if (cur_ft == Text)
                                                        {
                                                            char **field = new char*;
                                                    
                                                            getText(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), field);
                                                            cur_select.push_back(*field);
                                                    
                                                            delete field;
                                                        }
                                                        //Push back long field
                                                        else 
                                                        {
                                                            long field;
                                                    
                                                            getLong(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), &field);
                                                            cur_select.push_back(std::to_string(field));
                                                    
                                                        }
                                                    }
                                                    
                                                    delete field;
                                                    moveNext(tableHandle);
                                                }
                                                for (unsigned j = 0; j < fields; j++)
                                                {
                                                    movePrevios(tableHandle);
                                                }
                                            }
                                            selected_fields.push_back(cur_select);
                                            for (unsigned j = 0; j < fields; j++)
                                            {
                                                moveNext(tableHandle);
                                            }
                                        }
                                        else
                                        {
                                            for (unsigned i = 0; i < fields; i++)
                                                moveNext(tableHandle);
                                        }
                                        
                                        
                                    }
                                }
                                else
                                {
                                    error_message = "Error: non-matching expression type and constant type in WHERE clause";
                                    output = false;
                                }
                                
                            }
                            else 
                            {
                                error_message = "Error: non-existing field name in WHERE clause";
                                output = false;
                            }
                        }
                    }
                    else
                    {
                        while (!afterLast(tableHandle))
                        {
                            
                            int flag = 0;
                            for (unsigned i = 0; i < fields; i++)
                            {
                                int j = 0;
                                int exp = parser::CalculateExpression(&tableHandle, table::where_in_expr, j);
                                char **field = new char*;
                                for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                                {
                                    if (std::stoi(table::where_in_constlist[i]) == exp)
                                    {
                                        flag = 1;
                                    }
                                }
                                
                                
                                moveNext(tableHandle);
                                delete field;
                            
                            }
                            
                            for (unsigned i = 0; i < fields; i++)
                                movePrevios(tableHandle);
                                
                            if (table::where_not) flag = (flag+1)%2;
                            if (!flag)
                            {
                                std::vector <std::string> cur_select;
                                for (long unsigned i = 0; i < table::_delete.field_list.size(); i++)
                                {
                                        
                                    FieldType cur_ft;
                                        
                                    getFieldType(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), &cur_ft);
                                    for (unsigned j = 0; j < fields; j++)
                                    {
                                        char **field = new char*;
                                            
                                        getFieldName(tableHandle, j, field);
                                        if (strcmp(*field, (char*)(unsigned long)table::_delete.field_list[i].c_str()) == 0)
                                        {
                                            //Push back text field 
                                            if (cur_ft == Text)
                                            {
                                                char **field = new char*;
                                            
                                                getText(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), field);
                                                cur_select.push_back(*field);
                                            
                                                delete field;
                                            }
                                            //Push back long field
                                            else 
                                            {
                                                long field;
                                            
                                                getLong(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), &field);
                                                cur_select.push_back(std::to_string(field));
                                            
                                            }
                                        }
                                            
                                        delete field;
                                        moveNext(tableHandle);
                                    }
                                    for (unsigned j = 0; j < fields; j++)
                                    {
                                        movePrevios(tableHandle);
                                    }
                                }
                                selected_fields.push_back(cur_select);
                                for (unsigned j = 0; j < fields; j++)
                                {
                                    moveNext(tableHandle);
                                }
                            }
                            else
                            {
                                for (unsigned i = 0; i < fields; i++)
                                    moveNext(tableHandle);
                            }
                            
                        
                        }
                    }
                }
                
                //WHERE clause == WHERE <BOOL EXPRESSION>
                else if (table::where_clause == table::BOOL)
                {   
                    table::where_bool_expr.push_back(" ");
                    
                    while (!afterLast(tableHandle))
                    {
                        int flag = 0;
                        for (unsigned i = 0; i < fields; i++)
                        {
                            int j = 0;
                            bool exp = parser::CalculateBoolExpression(&tableHandle, table::where_bool_expr, j);
                            char **field = new char*;
                            if (exp) flag = 1;
                            
                            
                            moveNext(tableHandle);
                            delete field;
                            
                        }
                            
                        for (unsigned i = 0; i < fields; i++)
                            movePrevios(tableHandle);
                            
                        if (!flag)
                        {
                            std::vector <std::string> cur_select;
                            for (long unsigned i = 0; i < table::_delete.field_list.size(); i++)
                            {
                                    
                                FieldType cur_ft;
                                    
                                getFieldType(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), &cur_ft);
                                for (unsigned j = 0; j < fields; j++)
                                {
                                    char **field = new char*;
                                        
                                    getFieldName(tableHandle, j, field);
                                    if (strcmp(*field, (char*)(unsigned long)table::_delete.field_list[i].c_str()) == 0)
                                    {
                                        //Push back text field 
                                        if (cur_ft == Text)
                                        {
                                            char **field = new char*;
                                        
                                            getText(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), field);
                                            cur_select.push_back(*field);
                                        
                                            delete field;
                                        }
                                        //Push back long field
                                        else 
                                        {
                                            long field;
                                        
                                            getLong(tableHandle, (char*)(unsigned long)table::_delete.field_list[i].c_str(), &field);
                                            cur_select.push_back(std::to_string(field));
                                        
                                        }
                                    }
                                        
                                    delete field;
                                    moveNext(tableHandle);
                                }
                                for (unsigned j = 0; j < fields; j++)
                                {
                                    movePrevios(tableHandle);
                                }
                            }
                            selected_fields.push_back(cur_select);
                            for (unsigned j = 0; j < fields; j++)
                            {
                                moveNext(tableHandle);
                            }
                        }
                        else
                        {
                            for (unsigned i = 0; i < fields; i++)
                                moveNext(tableHandle);
                        }
                    }
                    
                }
                
                //And now recreate the table?

                fields = table::_delete.field_list.size();
                struct TableStruct t_struct;
                t_struct.numOfFields = fields;
                struct FieldDef *fd = new FieldDef[fields];
                for (unsigned i = 0; i < fields; i++)
                {
                    strcpy(fd[i].name, (char*)(unsigned long)table::_delete.field_list[i].c_str());
                    FieldType ft;
                    getFieldType(tableHandle, fd[i].name, &ft);
                    fd[i].type = ft;
                    unsigned int len;
                    getFieldLen(tableHandle, fd[i].name, &len);
                    fd[i].len = len;
                }
                t_struct.fieldsDef = fd;
                    
                char *t_name = new char[50]; 
                strcpy(t_name,table::_delete.name);
                closeTable(tableHandle);
                createTable(t_name, &t_struct);
                openTable(t_name, &tableHandle);
                    
                for (long unsigned i = 0; i < selected_fields.size(); i++)
                {
                    for (unsigned j = 0; j < fields; j++)
                    {
                        char **field = new char*;
                        FieldType ft;
                        getFieldName(tableHandle, j, field);
                        getFieldType(tableHandle, *field, &ft);
                        
                        if (ft == Long)
                        {
                            createNew(tableHandle);
                            putLongNew(tableHandle, *field, std::stoi(selected_fields[i][j]));
                            insertzNew(tableHandle);
                        }
                        else if (ft == Text)
                        {
                            createNew(tableHandle);
                            putTextNew(tableHandle, *field, (char*)(unsigned long)selected_fields[i][j].c_str());
                            insertzNew(tableHandle);
                        }
                        
                        delete field;
                    }
                }
                    
                closeTable(tableHandle);
                delete []t_name;
                delete []fd;
                
                
            }
            else
            {
                error_message = "Error: bad file name in DELETE";
                output = false;
            }
            
            
            
            delete []t_name;
            delete []table::_delete.name;
        }
        
        
        //UPDATE TABLE
        else if (table::sentence == table::UPDATE)
        {
            
            char *t_name = new char[50]; 
            THandle tableHandle;
            strcpy(t_name,table::update.name);
            if(openTable(t_name, &tableHandle) == 0)
            {
                unsigned int fields;
                getFieldsNum(tableHandle, &fields);
                FieldType ft;
                if(getFieldType(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), &ft) == 0)
                {
                    moveFirst(tableHandle);
                    if (table::where_clause == table::ALL)
                    {
                        while (!afterLast(tableHandle))
                        {
                            if (ft == Long)
                            {
                                int j = 0;
                                long expr;
                                expr = parser::CalculateExpression(&tableHandle, table::update.expr, j);
                                startEdit(tableHandle);
                                putLong(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), expr);
                                finishEdit(tableHandle);
                            }
                            else if (ft == Text)
                            {
                                FieldType ft2;
                                if(getFieldType(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), &ft2) == 0)
                                {
                                    char **field = new char*;
                                    std::string wtf;
                                    for (unsigned i = 0; i < fields; i++)
                                    {
                                        char **fieldname = new char*;
                                        
                                        getFieldName(tableHandle, i, fieldname);
                                        if (strcmp(*fieldname, (char*)(unsigned long)table::update.expr[0].c_str()) == 0)
                                        {   
                                            getText(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), field);
                                            wtf = *field;

                                            
                                        }
                                        
                                        moveNext(tableHandle);
                                        delete fieldname;
                                    }
                                    for (unsigned i = 0; i < fields; i++)
                                        movePrevios(tableHandle);
                                    
                                    for (unsigned i = 0; i < fields; i++)
                                    {
                                        startEdit(tableHandle);
                                        putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)wtf.c_str());
                                        finishEdit(tableHandle);
                                        moveNext(tableHandle);
                                    }
                                    
                                    
                                    movePrevios(tableHandle);
                                    
                                    delete field;
                                }
                                else if (table::update.expr[0][0] == '\'')
                                {
                                    std::string help = table::update.expr[0];
                                    
                                    help.pop_back();
                                    help.erase(help.begin());
                                    startEdit(tableHandle);
                                    putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)help.c_str());
                                    finishEdit(tableHandle);
                                }
                                else
                                {
                                    error_message = "Error: bad expression in UPDATE";
                                    output = false;
                                }
                            }
                            
                            
                            moveNext(tableHandle);
                        }
                        
                    }
                    else if (table::where_clause == table::LIKE)
                    {
                       
                        FieldType ftype;
                        if(getFieldType(tableHandle, (char*)(unsigned long)table::where_like_field.c_str(), &ftype) == 0)
                        {
                            if (ftype == Text)
                            {
                                table::where_like_sample.pop_back();
                                table::where_like_sample.erase(table::where_like_sample.begin());
                                while (!afterLast(tableHandle))
                                {
                                    char **field = new char*;
                                    std::string wtf;
                                    for (unsigned i = 0; i < fields; i++)
                                    {
                                        char **fieldname = new char*;
                                        
                                        getFieldName(tableHandle, i, fieldname);
                                        if (strcmp(*fieldname, (char*)(unsigned long)table::where_like_field.c_str()) == 0)
                                        {   
                                            
                                            getText(tableHandle, (char*)(unsigned long)table::where_like_field.c_str(), field);
                                            wtf = *field;
                                        }
                                        
                                        moveNext(tableHandle);
                                        delete fieldname;
                                    }
                                    for (unsigned i = 0; i < fields; i++)
                                        movePrevios(tableHandle);
                                    
                                    if (strcmp(wtf.c_str(), table::where_like_sample.c_str()) == 0)
                                    {
                                        if (ft == Long)
                                        {
                                            int j = 0;
                                            long expr;
                                            expr = parser::CalculateExpression(&tableHandle, table::update.expr, j);
                                            startEdit(tableHandle);
                                            putLong(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), expr);
                                            finishEdit(tableHandle);
                                        }
                                        else if (ft == Text)
                                        {
                                            FieldType ft2;
                                            if(getFieldType(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), &ft2) == 0)
                                            {
                                                char **field = new char*;
                                                std::string wtf;
                                                for (unsigned i = 0; i < fields; i++)
                                                {
                                                    char **fieldname = new char*;
                                                    
                                                    getFieldName(tableHandle, i, fieldname);
                                                    if (strcmp(*fieldname, (char*)(unsigned long)table::update.expr[0].c_str()) == 0)
                                                    {   
                                                        getText(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), field);
                                                        wtf = *field;

                                                        
                                                    }
                                                    
                                                    moveNext(tableHandle);
                                                    delete fieldname;
                                                }
                                                for (unsigned i = 0; i < fields; i++)
                                                    movePrevios(tableHandle);
                                                
                                                for (unsigned i = 0; i < fields; i++)
                                                {
                                                    startEdit(tableHandle);
                                                    putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)wtf.c_str());
                                                    finishEdit(tableHandle);
                                                    moveNext(tableHandle);
                                                }
                                                
                                                
                                                movePrevios(tableHandle);
                                                
                                                delete field;
                                            }
                                            else if (table::update.expr[0][0] == '\'')
                                            {
                                                std::string help = table::update.expr[0];
                                                
                                                help.pop_back();
                                                help.erase(help.begin());
                                                startEdit(tableHandle);
                                                putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)help.c_str());
                                                finishEdit(tableHandle);
                                            }
                                            else
                                            {
                                                error_message = "Error: bad expression in UPDATE";
                                                output = false;
                                            }
                                        }
                                        
                                        
                                        
                                    }
                                    
                                    for (unsigned i = 0; i < fields; i++)
                                        moveNext(tableHandle);
                                    delete field;
                                }
                            }
                            else 
                            {
                                error_message = "Error: field name in WHERE clause must be of TEXT type";
                                output = false;
                            }
                        }
                        else
                        {
                            error_message = "Error: non-existing field name";
                            output = false;
                        }
                        
                    }
                    else if (table::where_clause == table::IN)
                    {
                        
                        table::where_in_expr.push_back(" ");
                        if (table::where_in_constlist_type == table::TEXT)
                        {
                            
                            if (table::where_in_expr[0][0] == '\'')
                            {
                                //Expression is string
                                //Just search through the const list
                                int flag = 0;
                                for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                                {
                                    if (table::where_in_constlist[i] == table::where_in_expr[0])
                                    {
                                        flag = 1;
                                    }
                                }
                                if (table::where_not) flag = (flag+1)%2;
                                if (flag)
                                {
                                    while (!afterLast(tableHandle))
                                    {
                                        if (ft == Long)
                                        {
                                            int j = 0;
                                            long expr;
                                            expr = parser::CalculateExpression(&tableHandle, table::update.expr, j);
                                            startEdit(tableHandle);
                                            putLong(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), expr);
                                            finishEdit(tableHandle);
                                        }
                                        else if (ft == Text)
                                        {
                                            FieldType ft2;
                                            if(getFieldType(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), &ft2) == 0)
                                            {
                                                char **field = new char*;
                                                std::string wtf;
                                                for (unsigned i = 0; i < fields; i++)
                                                {
                                                    char **fieldname = new char*;
                                                    
                                                    getFieldName(tableHandle, i, fieldname);
                                                    if (strcmp(*fieldname, (char*)(unsigned long)table::update.expr[0].c_str()) == 0)
                                                    {   
                                                        getText(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), field);
                                                        wtf = *field;

                                                        
                                                    }
                                                    
                                                    moveNext(tableHandle);
                                                    delete fieldname;
                                                }
                                                for (unsigned i = 0; i < fields; i++)
                                                    movePrevios(tableHandle);
                                                
                                                for (unsigned i = 0; i < fields; i++)
                                                {
                                                    startEdit(tableHandle);
                                                    putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)wtf.c_str());
                                                    finishEdit(tableHandle);
                                                    moveNext(tableHandle);
                                                }
                                                
                                                
                                                movePrevios(tableHandle);
                                                
                                                delete field;
                                            }
                                            else if (table::update.expr[0][0] == '\'')
                                            {
                                                std::string help = table::update.expr[0];
                                                
                                                help.pop_back();
                                                help.erase(help.begin());
                                                startEdit(tableHandle);
                                                putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)help.c_str());
                                                finishEdit(tableHandle);
                                            }
                                            else
                                            {
                                                error_message = "Error: bad expression in UPDATE";
                                                output = false;
                                            }
                                        }
                                        
                                        
                                        moveNext(tableHandle);
                                    }
                                }
                            }
                            else 
                            {
                                //Expression is text field name
                
                                FieldType ft1;
                                if (getFieldType(tableHandle, (char*)(unsigned long)table::where_in_expr[0].c_str(), &ft1) == 0)
                                {
                                    if (ft1 == Text)
                                    {
                                        
                                        for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                                        {
                                            table::where_in_constlist[i].pop_back();
                                            table::where_in_constlist[i].erase(table::where_in_constlist[i].begin());
                                        }
                                        
                                        while (!afterLast(tableHandle))
                                        {
                                            int flag = 0;
                                            
                                            for (unsigned i = 0; i < fields; i++)
                                            {
                                                
                                                char **field = new char*;
                                                getText(tableHandle, (char*)(unsigned long)table::where_in_expr[0].c_str(), field);
                                                for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                                                {
                                                    if (strcmp(*field, table::where_in_constlist[i].c_str()) == 0)
                                                    {
                                                        flag = 1;
                                                    }
                                                }
                                                
                                                
                                                moveNext(tableHandle);
                                                delete field;
                                
                                            }
                                            
                                            for (unsigned i = 0; i < fields; i++)
                                                movePrevios(tableHandle);
                                            
                                            if (table::where_not) flag = (flag+1)%2;
                                            if (flag)
                                            {
                                                
                                                if (ft == Long)
                                                {
                                                    int j = 0;
                                                    long expr;
                                                    expr = parser::CalculateExpression(&tableHandle, table::update.expr, j);
                                                    startEdit(tableHandle);
                                                    putLong(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), expr);
                                                    finishEdit(tableHandle);
                                                }
                                                else if (ft == Text)
                                                {
                                                    FieldType ft2;
                                                    if(getFieldType(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), &ft2) == 0)
                                                    {
                                                        char **field = new char*;
                                                        std::string wtf;
                                                        for (unsigned i = 0; i < fields; i++)
                                                        {
                                                            char **fieldname = new char*;
                                                            
                                                            getFieldName(tableHandle, i, fieldname);
                                                            if (strcmp(*fieldname, (char*)(unsigned long)table::update.expr[0].c_str()) == 0)
                                                            {   
                                                                getText(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), field);
                                                                wtf = *field;

                                                                
                                                            }
                                                            
                                                            moveNext(tableHandle);
                                                            delete fieldname;
                                                        }
                                                        for (unsigned i = 0; i < fields; i++)
                                                            movePrevios(tableHandle);
                                                        
                                                        for (unsigned i = 0; i < fields; i++)
                                                        {
                                                            startEdit(tableHandle);
                                                            putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)wtf.c_str());
                                                            finishEdit(tableHandle);
                                                            moveNext(tableHandle);
                                                        }
                                                        
                                                        
                                                        movePrevios(tableHandle);
                                                        
                                                        delete field;
                                                    }
                                                    else if (table::update.expr[0][0] == '\'')
                                                    {
                                                        std::string help = table::update.expr[0];
                                                        
                                                        help.pop_back();
                                                        help.erase(help.begin());
                                                        startEdit(tableHandle);
                                                        putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)help.c_str());
                                                        finishEdit(tableHandle);
                                                    }
                                                    else
                                                    {
                                                        error_message = "Error: bad expression in UPDATE";
                                                        output = false;
                                                    }
                                                }
                                                for (unsigned j = 0; j < fields; j++)
                                                {
                                                    moveNext(tableHandle);
                                                }
                                            }
                                            else
                                            {
                                                for (unsigned i = 0; i < fields; i++)
                                                    moveNext(tableHandle);
                                            }
                                            
                                            
                                        }
                                    }
                                    else
                                    {
                                        error_message = "Error: non-matching expression type and constant type in WHERE clause";
                                        output = false;
                                    }
                                    
                                }
                                else 
                                {
                                    error_message = "Error: non-existing field name in WHERE clause";
                                    output = false;
                                }
                            }
                        }
                        else
                        {
                            while (!afterLast(tableHandle))
                            {
                                
                                int flag = 0;
                                for (unsigned i = 0; i < fields; i++)
                                {
                                    int j = 0;
                                    int exp = parser::CalculateExpression(&tableHandle, table::where_in_expr, j);
                                    char **field = new char*;
                                    for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                                    {
                                        if (std::stoi(table::where_in_constlist[i]) == exp)
                                        {
                                            flag = 1;
                                        }
                                    }
                                    
                                    
                                    moveNext(tableHandle);
                                    delete field;
                                
                                }
                                
                                for (unsigned i = 0; i < fields; i++)
                                    movePrevios(tableHandle);
                                    
                                if (table::where_not) flag = (flag+1)%2;
                                if (flag)
                                {
                                    if (ft == Long)
                                                {
                                                    int j = 0;
                                                    long expr;
                                                    expr = parser::CalculateExpression(&tableHandle, table::update.expr, j);
                                                    startEdit(tableHandle);
                                                    putLong(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), expr);
                                                    finishEdit(tableHandle);
                                                }
                                                else if (ft == Text)
                                                {
                                                    FieldType ft2;
                                                    if(getFieldType(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), &ft2) == 0)
                                                    {
                                                        char **field = new char*;
                                                        std::string wtf;
                                                        for (unsigned i = 0; i < fields; i++)
                                                        {
                                                            char **fieldname = new char*;
                                                            
                                                            getFieldName(tableHandle, i, fieldname);
                                                            if (strcmp(*fieldname, (char*)(unsigned long)table::update.expr[0].c_str()) == 0)
                                                            {   
                                                                getText(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), field);
                                                                wtf = *field;

                                                                
                                                            }
                                                            
                                                            moveNext(tableHandle);
                                                            delete fieldname;
                                                        }
                                                        for (unsigned i = 0; i < fields; i++)
                                                            movePrevios(tableHandle);
                                                        
                                                        for (unsigned i = 0; i < fields; i++)
                                                        {
                                                            startEdit(tableHandle);
                                                            putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)wtf.c_str());
                                                            finishEdit(tableHandle);
                                                            moveNext(tableHandle);
                                                        }
                                                        
                                                        
                                                        movePrevios(tableHandle);
                                                        
                                                        delete field;
                                                    }
                                                    else if (table::update.expr[0][0] == '\'')
                                                    {
                                                        std::string help = table::update.expr[0];
                                                        
                                                        help.pop_back();
                                                        help.erase(help.begin());
                                                        startEdit(tableHandle);
                                                        putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)help.c_str());
                                                        finishEdit(tableHandle);
                                                    }
                                                    else
                                                    {
                                                        error_message = "Error: bad expression in UPDATE";
                                                        output = false;
                                                    }
                                                }
                                                for (unsigned j = 0; j < fields; j++)
                                                {
                                                    moveNext(tableHandle);
                                                }
                                }
                                else
                                {
                                    for (unsigned i = 0; i < fields; i++)
                                        moveNext(tableHandle);
                                }
                                
                            
                            }
                        }
                        
                    }
                    else if (table::where_clause == table::BOOL)
                    {
                        
                        table::where_bool_expr.push_back(" ");
                    
                        while (!afterLast(tableHandle))
                        {
                            int flag = 0;
                            for (unsigned i = 0; i < fields; i++)
                            {
                                int j = 0;
                                bool exp = parser::CalculateBoolExpression(&tableHandle, table::where_bool_expr, j);
                                char **field = new char*;
                                if (exp) flag = 1;
                            
                            
                                moveNext(tableHandle);
                                delete field;
                            
                            }
                            
                            for (unsigned i = 0; i < fields; i++)
                                movePrevios(tableHandle);
                            
                            if (flag) 
                            {
                                if (ft == Long)
                                {
                                    int j = 0;
                                    long expr;
                                    expr = parser::CalculateExpression(&tableHandle, table::update.expr, j);
                                    startEdit(tableHandle);
                                    putLong(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), expr);
                                    finishEdit(tableHandle);
                                }
                                else if (ft == Text)
                                {
                                    FieldType ft2;
                                    if(getFieldType(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), &ft2) == 0)
                                    {
                                        char **field = new char*;
                                        std::string wtf;
                                        for (unsigned i = 0; i < fields; i++)
                                        {
                                            char **fieldname = new char*;
                                        
                                            getFieldName(tableHandle, i, fieldname);
                                            if (strcmp(*fieldname, (char*)(unsigned long)table::update.expr[0].c_str()) == 0)
                                            {   
                                                getText(tableHandle, (char*)(unsigned long)table::update.expr[0].c_str(), field);
                                                wtf = *field;

                                            
                                            }
                                                
                                            moveNext(tableHandle);
                                            delete fieldname;
                                        }
                                        for (unsigned i = 0; i < fields; i++)
                                            movePrevios(tableHandle);
                                                        
                                        for (unsigned i = 0; i < fields; i++)
                                        {
                                            startEdit(tableHandle);
                                            putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)wtf.c_str());
                                            finishEdit(tableHandle);
                                            moveNext(tableHandle);
                                        }
                                    
                                    
                                        movePrevios(tableHandle);
                                    
                                        delete field;
                                    }
                                    else if (table::update.expr[0][0] == '\'')
                                    {
                                        std::string help = table::update.expr[0];
                                        
                                        help.pop_back();
                                        help.erase(help.begin());
                                        startEdit(tableHandle);
                                        putText(tableHandle, (char*)(unsigned long)table::update.field_name.c_str(), (char*)(unsigned long)help.c_str());
                                        finishEdit(tableHandle);
                                    }
                                    else
                                    {
                                        error_message = "Error: bad expression in UPDATE";
                                        output = false;
                                    }
                                }
                                for (unsigned j = 0; j < fields; j++)
                                {
                                    moveNext(tableHandle);
                                }
                            }
                            else 
                            {
                                for (unsigned j = 0; j < fields; j++)
                                {
                                    moveNext(tableHandle);
                                }
                            }
                        }
                        
                    }
                }
                else 
                {
                    error_message = "Error: bad field name in UPDATE";
                    output = false;
                }   
                    
                    
            }
            else 
            {
                error_message = "Error: bad file name in UPDATE";
                output = false;
            }   
            
            closeTable(tableHandle);
            delete []t_name;
            delete []table::update.name;
        }
        
        
        //SELECT RECORDS FROM TABLE
        else if (table::sentence == table::SELECT)
        {
            
            char *t_name = new char[50]; 
            THandle tableHandle;
            strcpy(t_name,table::select.name);
            
            
            
            //Checking if table exists
            if (openTable(t_name, &tableHandle) == 0)
            {
                unsigned int fields;
                std::vector <std::vector <std::string> >  selected_fields;
                getFieldsNum(tableHandle, &fields);
                //If the sentence is SELECT * FROM...
                if (table::select.field_list[0] == "*")
                {
                    
                    table::select.field_list.clear();
                    
                    
                    for (unsigned i = 0; i < fields; i++)
                    {
                        char **field = new char*;
                        getFieldName(tableHandle, i, field);
                        table::select.field_list.push_back(*field);
                        delete field;
                    }
                    
                }
                
                //Checking if fields exist
                for (long unsigned i = 0; i < table::select.field_list.size(); i++)
                {
                    FieldType ft;
                    if (getFieldType(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &ft) != 0)
                    {
                        error_message = "Error: non-existing field name in SELECT";
                        output = false;
                    }
                }
                
                //Finally can start selecting!
                
                //WHERE clause == WHERE ALL 
                if (table::where_clause == table::ALL)
                {
                    
                    
                    //Constructing selected_fields matrix
                    while (!afterLast(tableHandle))
                    {
                        std::vector <std::string> cur_select;
                        for (long unsigned i = 0; i < table::select.field_list.size(); i++)
                        {
                            
                            FieldType cur_ft;
                            
                            getFieldType(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &cur_ft);
                            for (unsigned j = 0; j < fields; j++)
                            {
                                char **field = new char*;
                                
                                getFieldName(tableHandle, j, field);
                                if (strcmp(*field, (char*)(unsigned long)table::select.field_list[i].c_str()) == 0)
                                {
                                    //Push back text field 
                                    if (cur_ft == Text)
                                    {
                                        char **field = new char*;
                                
                                        getText(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), field);
                                        cur_select.push_back(*field);
                                
                                        delete field;
                                    }
                                    //Push back long field
                                    else 
                                    {
                                        long field;
                                
                                        getLong(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &field);
                                        cur_select.push_back(std::to_string(field));
                                
                                    }
                                }
                                
                                delete field;
                                moveNext(tableHandle);
                            }
                            for (unsigned j = 0; j < fields; j++)
                            {
                                movePrevios(tableHandle);
                            }
                        }
                        selected_fields.push_back(cur_select);
                        for (unsigned j = 0; j < fields; j++)
                        {
                            moveNext(tableHandle);
                        }
                    }
                    
                    
                    
                }
                
                //WHERE clause == WHERE ... LIKE ...
                else if (table::where_clause == table::LIKE)
                {
                    FieldType ftype;
                    
                    
                    //Does field in WHERE clause exist?
                    if(getFieldType(tableHandle, (char*)(unsigned long)table::where_like_field.c_str(), &ftype) == 0)
                    {
                        
                        if (ftype == Text)
                        {
                            table::where_like_sample.pop_back();
                            table::where_like_sample.erase(table::where_like_sample.begin());
                            
                            while (!afterLast(tableHandle))
                            {
                                int flag = 0;
                                
                                for (unsigned i = 0; i < fields; i++)
                                {
                                    
                                    char **field = new char*;
                                    getText(tableHandle, (char*)(unsigned long)table::where_like_field.c_str(), field);
                                    
                                    if (strcmp(*field, table::where_like_sample.c_str()) == 0)
                                    {
                                        flag = 1;
                                    }
                                    
                                    moveNext(tableHandle);
                                    delete field;
                    
                                }
                                
                                for (unsigned i = 0; i < fields; i++)
                                    movePrevios(tableHandle);
                                
                                if (table::where_not) flag = (flag+1)%2;
                                if (flag)
                                {
                                    std::vector <std::string> cur_select;
                                    for (long unsigned i = 0; i < table::select.field_list.size(); i++)
                                    {
                                        
                                        FieldType cur_ft;
                                        
                                        getFieldType(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &cur_ft);
                                        for (unsigned j = 0; j < fields; j++)
                                        {
                                            char **field = new char*;
                                            
                                            getFieldName(tableHandle, j, field);
                                            if (strcmp(*field, (char*)(unsigned long)table::select.field_list[i].c_str()) == 0)
                                            {
                                                //Push back text field 
                                                if (cur_ft == Text)
                                                {
                                                    char **field = new char*;
                                            
                                                    getText(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), field);
                                                    cur_select.push_back(*field);
                                            
                                                    delete field;
                                                }
                                                //Push back long field
                                                else 
                                                {
                                                    long field;
                                            
                                                    getLong(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &field);
                                                    cur_select.push_back(std::to_string(field));
                                            
                                                }
                                            }
                                            
                                            delete field;
                                            moveNext(tableHandle);
                                        }
                                        for (unsigned j = 0; j < fields; j++)
                                        {
                                            movePrevios(tableHandle);
                                        }
                                    }
                                    selected_fields.push_back(cur_select);
                                    for (unsigned j = 0; j < fields; j++)
                                    {
                                        moveNext(tableHandle);
                                    }
                                }
                                else
                                {
                                    for (unsigned i = 0; i < fields; i++)
                                        moveNext(tableHandle);
                                }
                                
                                
                            }
                        }
                        else 
                        {
                            error_message = "Error: field name in WHERE clause must be of TEXT type";
                            output = false;
                        }
                    }
                    else
                    {
                        error_message = "Error: non-existing field name in WHERE clause";
                        output = false;
                    }
                    
                }
                
                //WHERE clause == WHERE ... IN ...
                else if (table::where_clause == table::IN)
                {
                    table::where_in_expr.push_back(" ");
                    if (table::where_in_constlist_type == table::TEXT)
                    {
                        
                        if (table::where_in_expr[0][0] == '\'')
                        {
                            //Expression is string
                            //Just search through the const list
                            int flag = 0;
                            for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                            {
                                if (table::where_in_constlist[i] == table::where_in_expr[0])
                                {
                                    flag = 1;
                                }
                            }
                            if (table::where_not) flag = (flag+1)%2;
                            if (flag)
                            {
                                while (!afterLast(tableHandle))
                                {
                                    std::vector <std::string> cur_select;
                                    for (long unsigned i = 0; i < table::select.field_list.size(); i++)
                                    {
                                        
                                        FieldType cur_ft;
                                        
                                        getFieldType(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &cur_ft);
                                        for (unsigned j = 0; j < fields; j++)
                                        {
                                            char **field = new char*;
                                            
                                            getFieldName(tableHandle, j, field);
                                            if (strcmp(*field, (char*)(unsigned long)table::select.field_list[i].c_str()) == 0)
                                            {
                                                //Push back text field 
                                                if (cur_ft == Text)
                                                {
                                                    char **field = new char*;
                                            
                                                    getText(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), field);
                                                    cur_select.push_back(*field);
                                            
                                                    delete field;
                                                }
                                                //Push back long field
                                                else 
                                                {
                                                    long field;
                                            
                                                    getLong(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &field);
                                                    cur_select.push_back(std::to_string(field));
                                            
                                                }
                                            }
                                            
                                            delete field;
                                            moveNext(tableHandle);
                                        }
                                        for (unsigned j = 0; j < fields; j++)
                                        {
                                            movePrevios(tableHandle);
                                        }
                                    }
                                    selected_fields.push_back(cur_select);
                                    for (unsigned j = 0; j < fields; j++)
                                    {
                                        moveNext(tableHandle);
                                    }
                                }
                            }
                        }
                        else 
                        {
                            //Expression is text field name
                            
                            FieldType ft;
                            if (getFieldType(tableHandle, (char*)(unsigned long)table::where_in_expr[0].c_str(), &ft) == 0)
                            {
                                if (ft == Text)
                                {
                                    
                                    for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                                    {
                                        table::where_in_constlist[i].pop_back();
                                        table::where_in_constlist[i].erase(table::where_in_constlist[i].begin());
                                    }
                                    
                                    while (!afterLast(tableHandle))
                                    {
                                        int flag = 0;
                                        
                                        for (unsigned i = 0; i < fields; i++)
                                        {
                                            
                                            char **field = new char*;
                                            getText(tableHandle, (char*)(unsigned long)table::where_in_expr[0].c_str(), field);
                                            for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                                            {
                                                if (strcmp(*field, table::where_in_constlist[i].c_str()) == 0)
                                                {
                                                    flag = 1;
                                                }
                                            }
                                            
                                            
                                            moveNext(tableHandle);
                                            delete field;
                            
                                        }
                                        
                                        for (unsigned i = 0; i < fields; i++)
                                            movePrevios(tableHandle);
                                        
                                        if (table::where_not) flag = (flag+1)%2;
                                        if (flag)
                                        {
                                            
                                            std::vector <std::string> cur_select;
                                            for (long unsigned i = 0; i < table::select.field_list.size(); i++)
                                            {
                                                
                                                FieldType cur_ft;
                                                
                                                getFieldType(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &cur_ft);
                                                for (unsigned j = 0; j < fields; j++)
                                                {
                                                    char **field = new char*;
                                                    
                                                    getFieldName(tableHandle, j, field);
                                                    if (strcmp(*field, (char*)(unsigned long)table::select.field_list[i].c_str()) == 0)
                                                    {
                                                        //Push back text field 
                                                        if (cur_ft == Text)
                                                        {
                                                            char **field = new char*;
                                                    
                                                            getText(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), field);
                                                            cur_select.push_back(*field);
                                                    
                                                            delete field;
                                                        }
                                                        //Push back long field
                                                        else 
                                                        {
                                                            long field;
                                                    
                                                            getLong(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &field);
                                                            cur_select.push_back(std::to_string(field));
                                                    
                                                        }
                                                    }
                                                    
                                                    delete field;
                                                    moveNext(tableHandle);
                                                }
                                                for (unsigned j = 0; j < fields; j++)
                                                {
                                                    movePrevios(tableHandle);
                                                }
                                            }
                                            selected_fields.push_back(cur_select);
                                            for (unsigned j = 0; j < fields; j++)
                                            {
                                                moveNext(tableHandle);
                                            }
                                        }
                                        else
                                        {
                                            for (unsigned i = 0; i < fields; i++)
                                                moveNext(tableHandle);
                                        }
                                        
                                        
                                    }
                                }
                                else
                                {
                                    error_message = "Error: non-matching expression type and constant type in WHERE clause";
                                    output = false;
                                }
                                
                            }
                            else 
                            {
                                error_message = "Error: non-existing field name in WHERE clause";
                                output = false;
                            }
                        }
                    }
                    else
                    {
                        while (!afterLast(tableHandle))
                        {
                            
                            int flag = 0;
                            for (unsigned i = 0; i < fields; i++)
                            {
                                int j = 0;
                                int exp = parser::CalculateExpression(&tableHandle, table::where_in_expr, j);
                                char **field = new char*;
                                for (long unsigned i = 0; i < table::where_in_constlist.size(); i++)
                                {
                                    if (std::stoi(table::where_in_constlist[i]) == exp)
                                    {
                                        flag = 1;
                                    }
                                }
                                
                                
                                moveNext(tableHandle);
                                delete field;
                            
                            }
                            
                            for (unsigned i = 0; i < fields; i++)
                                movePrevios(tableHandle);
                                
                            if (table::where_not) flag = (flag+1)%2;
                            if (flag)
                            {
                                std::vector <std::string> cur_select;
                                for (long unsigned i = 0; i < table::select.field_list.size(); i++)
                                {
                                        
                                    FieldType cur_ft;
                                        
                                    getFieldType(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &cur_ft);
                                    for (unsigned j = 0; j < fields; j++)
                                    {
                                        char **field = new char*;
                                            
                                        getFieldName(tableHandle, j, field);
                                        if (strcmp(*field, (char*)(unsigned long)table::select.field_list[i].c_str()) == 0)
                                        {
                                            //Push back text field 
                                            if (cur_ft == Text)
                                            {
                                                char **field = new char*;
                                            
                                                getText(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), field);
                                                cur_select.push_back(*field);
                                            
                                                delete field;
                                            }
                                            //Push back long field
                                            else 
                                            {
                                                long field;
                                            
                                                getLong(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &field);
                                                cur_select.push_back(std::to_string(field));
                                            
                                            }
                                        }
                                            
                                        delete field;
                                        moveNext(tableHandle);
                                    }
                                    for (unsigned j = 0; j < fields; j++)
                                    {
                                        movePrevios(tableHandle);
                                    }
                                }
                                selected_fields.push_back(cur_select);
                                for (unsigned j = 0; j < fields; j++)
                                {
                                    moveNext(tableHandle);
                                }
                            }
                            else
                            {
                                for (unsigned i = 0; i < fields; i++)
                                    moveNext(tableHandle);
                            }
                            
                        
                        }
                    }
                }
                
                //WHERE clause == WHERE <BOOL EXPRESSION>
                else if (table::where_clause == table::BOOL)
                {
                        
                    table::where_bool_expr.push_back(" ");
                    
                    while (!afterLast(tableHandle))
                    {
                        int flag = 0;
                        for (unsigned i = 0; i < fields; i++)
                        {
                            int j = 0;
                            bool exp = parser::CalculateBoolExpression(&tableHandle, table::where_bool_expr, j);
                            char **field = new char*;
                            if (exp) flag = 1;
                            
                            
                            moveNext(tableHandle);
                            delete field;
                            
                        }
                            
                        for (unsigned i = 0; i < fields; i++)
                            movePrevios(tableHandle);
                            
                        if (flag)
                        {
                            std::vector <std::string> cur_select;
                            for (long unsigned i = 0; i < table::select.field_list.size(); i++)
                            {
                                    
                                FieldType cur_ft;
                                    
                                getFieldType(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &cur_ft);
                                for (unsigned j = 0; j < fields; j++)
                                {
                                    char **field = new char*;
                                        
                                    getFieldName(tableHandle, j, field);
                                    if (strcmp(*field, (char*)(unsigned long)table::select.field_list[i].c_str()) == 0)
                                    {
                                        //Push back text field 
                                        if (cur_ft == Text)
                                        {
                                            char **field = new char*;
                                        
                                            getText(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), field);
                                            cur_select.push_back(*field);
                                        
                                            delete field;
                                        }
                                        //Push back long field
                                        else 
                                        {
                                            long field;
                                        
                                            getLong(tableHandle, (char*)(unsigned long)table::select.field_list[i].c_str(), &field);
                                            cur_select.push_back(std::to_string(field));
                                        
                                        }
                                    }
                                        
                                    delete field;
                                    moveNext(tableHandle);
                                }
                                for (unsigned j = 0; j < fields; j++)
                                {
                                    movePrevios(tableHandle);
                                }
                            }
                            selected_fields.push_back(cur_select);
                            for (unsigned j = 0; j < fields; j++)
                            {
                                moveNext(tableHandle);
                            }
                        }
                        else
                        {
                            for (unsigned i = 0; i < fields; i++)
                                moveNext(tableHandle);
                        }
                    }
                    
                }
                
                //And now recreate the table?

                fields = table::select.field_list.size();
                struct TableStruct t_struct;
                t_struct.numOfFields = fields;
                struct FieldDef *fd = new FieldDef[fields];
                for (unsigned i = 0; i < fields; i++)
                {
                    strcpy(fd[i].name, (char*)(unsigned long)table::select.field_list[i].c_str());
                    FieldType ft;
                    getFieldType(tableHandle, fd[i].name, &ft);
                    fd[i].type = ft;
                    unsigned int len;
                    getFieldLen(tableHandle, fd[i].name, &len);
                    fd[i].len = len;
                }
                t_struct.fieldsDef = fd;
                    
                char *t_name = new char[50]; 
                strcpy(t_name,table::select.name);
                closeTable(tableHandle);
                createTable(t_name, &t_struct);
                openTable(t_name, &tableHandle);
                    
                for (long unsigned i = 0; i < selected_fields.size(); i++)
                {
                    for (unsigned j = 0; j < fields; j++)
                    {
                        char **field = new char*;
                        FieldType ft;
                        getFieldName(tableHandle, j, field);
                        getFieldType(tableHandle, *field, &ft);
                        
                        if (ft == Long)
                        {
                            createNew(tableHandle);
                            putLongNew(tableHandle, *field, std::stoi(selected_fields[i][j]));
                            insertzNew(tableHandle);
                        }
                        else if (ft == Text)
                        {
                            createNew(tableHandle);
                            putTextNew(tableHandle, *field, (char*)(unsigned long)selected_fields[i][j].c_str());
                            insertzNew(tableHandle);
                        }
                        
                        delete field;
                    }
                }
                    
                closeTable(tableHandle);
                delete []t_name;
                delete []fd;
                
                
            }
            else
            {
                error_message = "Error: bad file name in SELECT";
                output = false;
            }
            
            
            
            delete []t_name;
            delete []table::select.name;
        }
    
    
    // ________________________
    
    }
    
        table::insert.field_value.clear();
        table::insert.field_type.clear();
        table::create.field_type.clear();
        table::create.field_size.clear();
        table::_delete.field_list.clear();
        table::update.expr.clear();
        table::select.field_list.clear();
        table::where_in_expr.clear();
        table::where_in_constlist.clear();
        table::where_bool_expr.clear();
        table::where_not = false;
        look_ahead.clear();
        look_ahead_text.clear();
        parser::i = 0;
        
        if (do_delete)
        {
            if (table::sentence == table::CREATE)
                delete []table::create.name;
            else if (table::sentence == table::INSERT)
                delete []table::insert.name;
            else if (table::sentence == table::DROP)
                delete []table::drop.name;
            else if (table::sentence == table::DELETE)
                delete []table::_delete.name;
            else if (table::sentence == table::UPDATE)
                delete []table::update.name;
            else if (table::sentence == table::SELECT)
                delete []table::select.name;
        }


        if (output) cout << "OK" << endl;
        else cout << error_message  << endl;
        
        if (table::sentence == table::EXIT)
        {
            break;
        }
    
}

    //table::PrintTable((char*)"table1");
    
    
    close(client);
    
    close(listener);

    delete []buf;
}