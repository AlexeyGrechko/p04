#include <sys/types.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <unistd.h>
#include <string>
#include <iostream>
using std::string;
using std::cout;
using std::endl;

int CreateListenerSocket(const char *c)
{ 
	int i = 0;
	int out = socket(AF_UNIX, SOCK_STREAM, 0);
	struct sockaddr_un addr; 
	
	addr.sun_family = AF_UNIX;
	for (i = 0; i <= 108; i++)
	{
		addr.sun_path[i] = c[i];
		if (c[i] == '\0') break; 
	}
	unlink(c);
	if (bind(out, (struct sockaddr *)&addr, sizeof(addr)) < 0)
	{
		perror("bind");
        exit(2);
	}
	listen(out, 1);
	return out;
}

int ReceiveFromClient(int client, char *buf, int buf_len)
{
	
	recv(client, buf, buf_len, 0);
	cout << "server got your message" << endl;
	return 0;
	//do whatever with data afterwards
}


int SendToClient(int client, const char *buf, int buf_len)
{
	send(client, buf, buf_len, 0);
	cout << "server message sent" << endl;
	return 0;
}

int ConnectToServer(const char *c)
{
	int i = 0;
	//char cur_char;
	int out = socket(AF_UNIX, SOCK_STREAM, 0);
	struct sockaddr_un addr; 
	addr.sun_family = AF_UNIX;
	for (i = 0; i <= 108; i++)
	{
		addr.sun_path[i] = c[i];
		if (c[i] == '\0') break; 
	}
	if(connect(out, (struct sockaddr *)&addr, sizeof(addr)) == 0)
		return out;
	else return -1;
}

int SendToServer(int client, const char *buf, int buf_len)
{
	send(client, buf, buf_len, 0);
	cout << "message sent" << endl;
	//do whatever with data afterwards
	return 0;
}

int ReceiveFromServer(int client, char *buf, int buf_len)
{
	recv(client, buf, buf_len, 0);
	//do whatever with data afterwards
	return 0;
}

int CloseSocket(int descr)
{
	close(descr);
	return 0;
}
