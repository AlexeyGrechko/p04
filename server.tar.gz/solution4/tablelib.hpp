#define MAX_TABLENAME_LEN 50
#define MAX_FIELDNAME_LEN 30
#define MAX_FIELDS 20
extern "C"
{
	#include "Table.h"
}

namespace table
{
	enum sentence_t {SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, ERROR, EXIT} sentence = ERROR;
	enum field_t {TEXT, LONG, STRING};
	enum where_t {ALL, LIKE, IN, BOOL};
	
	where_t where_clause;
	bool where_not = false;
	
	std::string where_like_field;
	std::string where_like_sample;
	
	std::vector <std::string> where_in_expr;
	std::vector <std::string> where_in_constlist;
	field_t where_in_expr_type;
	field_t where_in_constlist_type;
	
	std::vector <std::string> where_bool_expr;
	
	struct CreateTable
	{
		int fields;
		char *name;
		char field_name[MAX_FIELDS][MAX_FIELDNAME_LEN];
		std::vector <enum field_t> field_type;
		std::vector <unsigned> field_size;

	} create;
	
	struct InsertIntoTable
	{
		unsigned fields;
		char *name;
		std::vector <std::string> field_value;
		std::vector <enum field_t> field_type;

	} insert;
	
	struct DropTable
	{
		char *name;

	} drop;
	
	struct DeleteFromTable
	{
		char *name;
		std::vector <std::string> field_list;
		
	} _delete;
	
	struct UpdateTable
	{
		char *name;
		std::string field_name;
		field_t expr_type;
		std::vector <std::string> expr;
		long long_const;
		
	} update;
	
	struct SelectFromTable
	{
		char *name;
		std::string field_name;
		std::vector <std::string> field_list;

	} select;
	
	void PrintTable(char *t_name)
	{
		THandle tableHandle;
		FieldType ft;
		unsigned int fields;
		int count = 0;
		
		cout << "--- TABLE " << t_name << " ---\n";
		openTable(t_name, &tableHandle);
		getFieldsNum(tableHandle, &fields);
		for (unsigned int i = 0; i < fields; i++)
		{
			char **field = new char*;
			
			getFieldName(tableHandle, i, field);
			cout << *field << " ";
			
			delete field;
		}
		cout << endl;
			
		while (!afterLast(tableHandle))
		{
			char **fieldname = new char*;
			getFieldName(tableHandle, count, fieldname);
			getFieldType(tableHandle, *fieldname, &ft);
			if (ft == Text)
			{
				char **fieldtext = new char*;
				getText(tableHandle, *fieldname, fieldtext);
				cout << *fieldtext << " ";
				delete fieldtext;
			}
			else
			{
				long fieldlong;
				getLong(tableHandle, *fieldname, &fieldlong);
				cout << fieldlong << " ";
			}
			count++;
			if (count%fields == 0)
			{
				count = 0;
				cout << endl;
			}
			
			delete fieldname;
			moveNext(tableHandle);
		}
		
		closeTable(tableHandle);
	}
	
}